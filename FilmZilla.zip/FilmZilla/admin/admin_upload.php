<?php include '../db.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Upload Movies | FilmZilla Admin</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    :root {
      --primary: #1e3c72;
      --secondary: #2a5298;
      --accent: #ff6b6b;
      --accent-hover: #ff5252;
      --card-bg: rgba(255, 255, 255, 0.95);
      --text: #333333;
      --text-light: #666666;
      --shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
      --transition: all 0.3s ease;
    }
    
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    
    body {
      background: linear-gradient(135deg, var(--primary), var(--secondary));
      color: var(--text);
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 20px;
      position: relative;
      overflow-x: hidden;
    }
    
    body::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-image: 
          radial-gradient(circle at 10% 20%, rgba(255, 255, 255, 0.05) 0%, transparent 20%),
          radial-gradient(circle at 90% 80%, rgba(255, 255, 255, 0.05) 0%, transparent 20%);
      z-index: -1;
    }
    
    .container {
      width: 100%;
      max-width: 800px;
      background: var(--card-bg);
      border-radius: 20px;
      box-shadow: var(--shadow);
      overflow: hidden;
      position: relative;
    }
    
    .container::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 5px;
      background: linear-gradient(to right, var(--accent), #ffa500, var(--accent));
    }
    
    .header {
      background: linear-gradient(135deg, var(--primary), var(--secondary));
      color: white;
      padding: 30px;
      text-align: center;
      position: relative;
    }
    
    .logo {
      font-size: 3rem;
      margin-bottom: 10px;
      display: inline-block;
      filter: drop-shadow(0 5px 15px rgba(0, 0, 0, 0.3));
    }
    
    h1 {
      font-size: 2.2rem;
      margin-bottom: 5px;
      font-weight: 700;
    }
    
    .subtitle {
      font-size: 1rem;
      opacity: 0.9;
    }
    
    .back-link {
      position: absolute;
      top: 20px;
      left: 20px;
      color: white;
      text-decoration: none;
      font-size: 1.2rem;
      transition: var(--transition);
    }
    
    .back-link:hover {
      transform: translateX(-5px);
    }
    
    .form-container {
      padding: 40px;
    }
    
    .form-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 20px;
    }
    
    .form-group {
      margin-bottom: 20px;
    }
    
    .form-group.full-width {
      grid-column: 1 / -1;
    }
    
    label {
      display: block;
      margin-bottom: 8px;
      font-weight: 600;
      color: var(--text);
    }
    
    .required::after {
      content: " *";
      color: var(--accent);
    }
    
    input, select, textarea {
      width: 100%;
      padding: 14px;
      border: 1px solid #ddd;
      border-radius: 10px;
      font-size: 1rem;
      transition: var(--transition);
      background: #f9f9f9;
    }
    
    input:focus, select:focus, textarea:focus {
      outline: none;
      border-color: var(--accent);
      box-shadow: 0 0 0 3px rgba(255, 107, 107, 0.2);
      background: white;
    }
    
    .file-input-container {
      position: relative;
      overflow: hidden;
      display: inline-block;
      width: 100%;
    }
    
    .file-input {
      position: absolute;
      left: -9999px;
    }
    
    .file-input-label {
      display: block;
      padding: 14px;
      background: #f0f0f0;
      border: 2px dashed #ccc;
      border-radius: 10px;
      text-align: center;
      cursor: pointer;
      transition: var(--transition);
    }
    
    .file-input-label:hover {
      background: #e8e8e8;
      border-color: var(--accent);
    }
    
    .file-input-label i {
      margin-right: 8px;
      color: var(--accent);
    }
    
    .file-name {
      margin-top: 5px;
      font-size: 0.9rem;
      color: var(--text-light);
    }
    
    textarea {
      resize: vertical;
      min-height: 100px;
    }
    
    .btn {
      display: block;
      width: 100%;
      padding: 16px;
      background: var(--accent);
      color: white;
      border: none;
      border-radius: 10px;
      font-size: 1.1rem;
      font-weight: 600;
      cursor: pointer;
      transition: var(--transition);
      box-shadow: 0 4px 10px rgba(255, 107, 107, 0.3);
      margin-top: 10px;
    }
    
    .btn:hover {
      background: var(--accent-hover);
      transform: translateY(-3px);
      box-shadow: 0 6px 15px rgba(255, 107, 107, 0.4);
    }
    
    .btn i {
      margin-right: 8px;
    }
    
    .msg {
      padding: 15px;
      border-radius: 10px;
      margin-top: 20px;
      text-align: center;
      font-weight: 600;
    }
    
    .success {
      background: #e8f5e9;
      color: #2e7d32;
      border: 1px solid #c8e6c9;
    }
    
    .error {
      background: #ffebee;
      color: #c62828;
      border: 1px solid #ffcdd2;
    }
    
    .form-footer {
      margin-top: 30px;
      text-align: center;
      font-size: 0.9rem;
      color: var(--text-light);
    }
    
    /* Animation for form elements */
    @keyframes fadeInUp {
      from {
        opacity: 0;
        transform: translateY(20px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
    
    .form-group {
      animation: fadeInUp 0.5s ease forwards;
      opacity: 0;
    }
    
    .form-group:nth-child(1) { animation-delay: 0.1s; }
    .form-group:nth-child(2) { animation-delay: 0.2s; }
    .form-group:nth-child(3) { animation-delay: 0.3s; }
    .form-group:nth-child(4) { animation-delay: 0.4s; }
    .form-group:nth-child(5) { animation-delay: 0.5s; }
    .form-group:nth-child(6) { animation-delay: 0.6s; }
    
    /* Responsive adjustments */
    @media (max-width: 768px) {
      .form-grid {
        grid-template-columns: 1fr;
      }
      
      .header {
        padding: 20px;
      }
      
      h1 {
        font-size: 1.8rem;
      }
      
      .form-container {
        padding: 30px 20px;
      }
    }
    
    @media (max-width: 480px) {
      .header {
        padding: 15px;
      }
      
      h1 {
        font-size: 1.6rem;
      }
      
      .logo {
        font-size: 2.5rem;
      }
    }
  </style>
</head>
<body>

<div class="container">
  <div class="header">
    <a href="admin_home.html" class="back-link">
      <i class="fas fa-arrow-left"></i> Back
    </a>
    <div class="logo">🎬</div>
    <h1>Upload New Movie</h1>
    <p class="subtitle">Add a new movie to the FilmZilla library</p>
  </div>
  
  <div class="form-container">
    <form method="POST" enctype="multipart/form-data" id="uploadForm">
      <div class="form-grid">
        <div class="form-group">
          <label for="title" class="required">Movie Title</label>
          <input type="text" id="title" name="title" placeholder="Enter movie title" required>
        </div>
        
        <div class="form-group">
          <label for="genre" class="required">Genre</label>
          <select id="genre" name="genre" required>
            <option value="">Select Genre</option>
            <option>Action</option>
            <option>Adventure</option>
            <option>Comedy</option>
            <option>Drama</option>
            <option>Horror</option>
            <option>Science Fiction</option>
            <option>Fantasy</option>
            <option>Thriller</option>
            <option>Crime</option>
            <option>Animation</option>
          </select>
        </div>
        
        
        <div class="form-group">
          <label for="thumbnail" class="required">Thumbnail Image</label>
          <div class="file-input-container">
            <input type="file" id="thumbnail" name="thumbnail" class="file-input" accept="image/*" required>
            <label for="thumbnail" class="file-input-label">
              <i class="fas fa-image"></i> Choose Thumbnail
            </label>
          </div>
          <div id="thumbnail-name" class="file-name">No file selected</div>
        </div>
        
        <div class="form-group">
          <label for="movie_file" class="required">Movie File</label>
          <div class="file-input-container">
            <input type="file" id="movie_file" name="movie_file" class="file-input" accept="video/*" required>
            <label for="movie_file" class="file-input-label">
              <i class="fas fa-film"></i> Choose Movie File
            </label>
          </div>
          <div id="movie-file-name" class="file-name">No file selected</div>
        </div>
        
      </div>
      
      <button type="submit" name="upload" class="btn">
        <i class="fas fa-cloud-upload-alt"></i> Upload Movie
      </button>
    </form>
    
    <?php
    if (isset($_POST['upload'])) {
        $title = mysqli_real_escape_string($conn, $_POST['title']);
        $genre = mysqli_real_escape_string($conn, $_POST['genre']);
        $year = isset($_POST['year']) ? mysqli_real_escape_string($conn, $_POST['year']) : NULL;
        $duration = isset($_POST['duration']) ? mysqli_real_escape_string($conn, $_POST['duration']) : NULL;
        $description = isset($_POST['description']) ? mysqli_real_escape_string($conn, $_POST['description']) : NULL;

        // Folder paths
        $thumb_dir = "admin/thumbnails/";
        $movie_dir = "admin/uploads/";

        // Create folders if not exist
        if (!is_dir($thumb_dir)) mkdir($thumb_dir, 0777, true);
        if (!is_dir($movie_dir)) mkdir($movie_dir, 0777, true);

        // File names with timestamp to avoid conflicts
        $thumb_ext = pathinfo($_FILES['thumbnail']['name'], PATHINFO_EXTENSION);
        $movie_ext = pathinfo($_FILES['movie_file']['name'], PATHINFO_EXTENSION);
        
        $thumb_name = time() . '_' . preg_replace('/[^a-zA-Z0-9]/', '_', $title) . '.' . $thumb_ext;
        $movie_name = time() . '_' . preg_replace('/[^a-zA-Z0-9]/', '_', $title) . '.' . $movie_ext;

        // Move uploaded files
        $thumb_upload = move_uploaded_file($_FILES['thumbnail']['tmp_name'], $thumb_dir . $thumb_name);
        $movie_upload = move_uploaded_file($_FILES['movie_file']['tmp_name'], $movie_dir . $movie_name);

        if ($thumb_upload && $movie_upload) {
            // Insert into DB
            $sql = "INSERT INTO movies (title, genre, thumbnail, file_path, uploaded_at)
                    VALUES ('$title', '$genre', '$thumb_name', '$movie_name', NOW())";
            if ($conn->query($sql) === TRUE) {
                echo "<div class='msg success'><i class='fas fa-check-circle'></i> Movie uploaded successfully!</div>";
            } else {
                echo "<div class='msg error'><i class='fas fa-exclamation-circle'></i> Database error: " . $conn->error . "</div>";
            }
        } else {
            echo "<div class='msg error'><i class='fas fa-exclamation-circle'></i> File upload failed. Please try again.</div>";
        }
    }
    ?>
    
    <div class="form-footer">
      <p><i class="fas fa-info-circle"></i> Supported formats: MP4, MKV, AVI for videos | JPG, PNG for thumbnails</p>
    </div>
  </div>
</div>

<script>
  // Update file names when files are selected
  document.getElementById('thumbnail').addEventListener('change', function(e) {
    const fileName = e.target.files[0] ? e.target.files[0].name : 'No file selected';
    document.getElementById('thumbnail-name').textContent = fileName;
  });
  
  document.getElementById('movie_file').addEventListener('change', function(e) {
    const fileName = e.target.files[0] ? e.target.files[0].name : 'No file selected';
    document.getElementById('movie-file-name').textContent = fileName;
  });
  
  // Form validation
  document.getElementById('uploadForm').addEventListener('submit', function(e) {
    const title = document.getElementById('title').value.trim();
    const genre = document.getElementById('genre').value;
    const thumbnail = document.getElementById('thumbnail').files.length;
    const movieFile = document.getElementById('movie_file').files.length;
    
    if (!title) {
      alert('Please enter a movie title');
      e.preventDefault();
      return;
    }
    
    if (!genre) {
      alert('Please select a genre');
      e.preventDefault();
      return;
    }
    
    if (!thumbnail) {
      alert('Please select a thumbnail image');
      e.preventDefault();
      return;
    }
    
    if (!movieFile) {
      alert('Please select a movie file');
      e.preventDefault();
      return;
    }
  });
</script>

</body>
</html>