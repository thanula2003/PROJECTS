<?php
include '../db.php'; // adjust if db.php is in another folder

$genres = ['Action','Adventure','Comedy','Drama','Horror','Science Fiction','Fantasy','Thriller','Crime','Animation'];
$message = '';

// Handle deletion
if (isset($_POST['delete_id'])) {
    $id = intval($_POST['delete_id']);
    $res = $conn->query("SELECT file_path, thumbnail FROM movies WHERE id=$id");
    if ($res && $res->num_rows > 0) {
        $row = $res->fetch_assoc();

        // Delete movie file
        if (file_exists("admin/uploads/".$row['file_path'])) unlink("admin/uploads/".$row['file_path']);
        // Delete thumbnail
        if (file_exists("admin/thumbnails/".$row['thumbnail'])) unlink("admin/thumbnails/".$row['thumbnail']);

        // Delete DB record
        $conn->query("DELETE FROM movies WHERE id=$id");
        $message = "<div class='msg success'><i class='fas fa-check-circle'></i> Movie deleted successfully!</div>";
    } else {
        $message = "<div class='msg error'><i class='fas fa-exclamation-circle'></i> Movie not found!</div>";
    }
}

// Handle genre selection
$selected_genre = isset($_POST['genre']) ? $_POST['genre'] : '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manage Movies | FilmZilla Admin</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    :root {
      --primary: #1e3c72;
      --secondary: #2a5298;
      --accent: #ff6b6b;
      --accent-hover: #ff5252;
      --danger: #e74c3c;
      --danger-hover: #c0392b;
      --card-bg: rgba(255, 255, 255, 0.95);
      --text: #333333;
      --text-light: #666666;
      --shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
      --transition: all 0.3s ease;
    }
    
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    
    body {
      background: linear-gradient(135deg, var(--primary), var(--secondary));
      color: var(--text);
      min-height: 100vh;
      padding: 20px;
      position: relative;
      overflow-x: hidden;
    }
    
    body::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-image: 
          radial-gradient(circle at 10% 20%, rgba(255, 255, 255, 0.05) 0%, transparent 20%),
          radial-gradient(circle at 90% 80%, rgba(255, 255, 255, 0.05) 0%, transparent 20%);
      z-index: -1;
    }
    
    .container {
      width: 100%;
      max-width: 1200px;
      margin: 0 auto;
      background: var(--card-bg);
      border-radius: 20px;
      box-shadow: var(--shadow);
      overflow: hidden;
      position: relative;
    }
    
    .container::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 5px;
      background: linear-gradient(to right, var(--accent), #ffa500, var(--accent));
    }
    
    .header {
      background: linear-gradient(135deg, var(--primary), var(--secondary));
      color: white;
      padding: 30px;
      text-align: center;
      position: relative;
    }
    
    .logo {
      font-size: 3rem;
      margin-bottom: 10px;
      display: inline-block;
      filter: drop-shadow(0 5px 15px rgba(0, 0, 0, 0.3));
    }
    
    h1 {
      font-size: 2.2rem;
      margin-bottom: 5px;
      font-weight: 700;
    }
    
    .subtitle {
      font-size: 1rem;
      opacity: 0.9;
    }
    
    .back-link {
      position: absolute;
      top: 20px;
      left: 20px;
      color: white;
      text-decoration: none;
      font-size: 1.2rem;
      transition: var(--transition);
    }
    
    .back-link:hover {
      transform: translateX(-5px);
    }
    
    .content {
      padding: 40px;
    }
    
    .filter-section {
      background: #f8f9fa;
      border-radius: 15px;
      padding: 25px;
      margin-bottom: 30px;
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
    }
    
    .filter-form {
      display: flex;
      align-items: center;
      gap: 15px;
      flex-wrap: wrap;
    }
    
    label {
      font-weight: 600;
      color: var(--text);
      margin-right: 10px;
    }
    
    select, .btn {
      padding: 12px 20px;
      border-radius: 10px;
      font-size: 1rem;
      transition: var(--transition);
    }
    
    select {
      border: 1px solid #ddd;
      background: white;
      min-width: 200px;
    }
    
    select:focus {
      outline: none;
      border-color: var(--accent);
      box-shadow: 0 0 0 3px rgba(255, 107, 107, 0.2);
    }
    
    .btn {
      background: var(--accent);
      color: white;
      border: none;
      cursor: pointer;
      font-weight: 600;
      box-shadow: 0 4px 10px rgba(255, 107, 107, 0.3);
    }
    
    .btn:hover {
      background: var(--accent-hover);
      transform: translateY(-3px);
      box-shadow: 0 6px 15px rgba(255, 107, 107, 0.4);
    }
    
    .btn i {
      margin-right: 8px;
    }
    
    .btn-danger {
      background: var(--danger);
      box-shadow: 0 4px 10px rgba(231, 76, 60, 0.3);
    }
    
    .btn-danger:hover {
      background: var(--danger-hover);
      box-shadow: 0 6px 15px rgba(231, 76, 60, 0.4);
    }
    
    .msg {
      padding: 15px;
      border-radius: 10px;
      margin-bottom: 20px;
      text-align: center;
      font-weight: 600;
    }
    
    .success {
      background: #e8f5e9;
      color: #2e7d32;
      border: 1px solid #c8e6c9;
    }
    
    .error {
      background: #ffebee;
      color: #c62828;
      border: 1px solid #ffcdd2;
    }
    
    .movie-container {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
      gap: 25px;
    }
    
    .movie-card {
      background: white;
      border-radius: 15px;
      overflow: hidden;
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
      transition: var(--transition);
      position: relative;
      border: 1px solid #f0f0f0;
    }
    
    .movie-card:hover {
      transform: translateY(-8px);
      box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
    }
    
    .movie-poster {
      width: 100%;
      height: 200px;
      object-fit: cover;
      display: block;
    }
    
    .movie-info {
      padding: 20px;
    }
    
    .movie-title {
      font-size: 1.2rem;
      font-weight: 600;
      margin-bottom: 10px;
      color: var(--text);
      line-height: 1.4;
    }
    
    .movie-meta {
      display: flex;
      justify-content: space-between;
      margin-bottom: 15px;
      font-size: 0.9rem;
      color: var(--text-light);
    }
    
    .movie-genre {
      background: #e9ecef;
      padding: 4px 10px;
      border-radius: 20px;
      font-size: 0.8rem;
      font-weight: 600;
    }
    
    .delete-form {
      margin-top: 15px;
    }
    
    .no-movies {
      grid-column: 1 / -1;
      text-align: center;
      padding: 60px 20px;
      color: var(--text-light);
      font-size: 1.1rem;
    }
    
    .no-movies i {
      font-size: 3rem;
      margin-bottom: 15px;
      display: block;
      color: #ddd;
    }
    
    .stats-bar {
      display: flex;
      justify-content: space-between;
      background: #f8f9fa;
      border-radius: 10px;
      padding: 15px 20px;
      margin-bottom: 30px;
      font-size: 0.9rem;
      color: var(--text-light);
    }
    
    .stats-item {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    
    .stats-item i {
      color: var(--accent);
    }
    
    /* Animation for movie cards */
    @keyframes fadeInUp {
      from {
        opacity: 0;
        transform: translateY(20px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
    
    .movie-card {
      animation: fadeInUp 0.5s ease forwards;
      opacity: 0;
    }
    
    /* Responsive adjustments */
    @media (max-width: 768px) {
      .header {
        padding: 20px;
      }
      
      h1 {
        font-size: 1.8rem;
      }
      
      .content {
        padding: 30px 20px;
      }
      
      .filter-form {
        flex-direction: column;
        align-items: stretch;
      }
      
      select {
        min-width: auto;
        width: 100%;
      }
      
      .movie-container {
        grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
      }
      
      .stats-bar {
        flex-direction: column;
        gap: 10px;
      }
    }
    
    @media (max-width: 480px) {
      .header {
        padding: 15px;
      }
      
      h1 {
        font-size: 1.6rem;
      }
      
      .logo {
        font-size: 2.5rem;
      }
      
      .movie-container {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>

<div class="container">
  <div class="header">
    <a href="admin_home.html" class="back-link">
      <i class="fas fa-arrow-left"></i> Back
    </a>
    <div class="logo">🎬</div>
    <h1>Manage Movies</h1>
    <p class="subtitle">View and delete movies from the FilmZilla library</p>
  </div>
  
  <div class="content">
    <?php echo $message; ?>
    
    <div class="filter-section">
      <form method="POST" class="filter-form">
        <label for="genre">Filter by Genre:</label>
        <select id="genre" name="genre" required>
          <option value="">-- Choose Genre --</option>
          <?php foreach($genres as $g) {
            $sel = ($g == $selected_genre) ? 'selected' : '';
            echo "<option value='$g' $sel>$g</option>";
          } ?>
        </select>
        <button type="submit" class="btn">
          <i class="fas fa-filter"></i> Show Movies
        </button>
      </form>
    </div>
    
    <?php if ($selected_genre != ''): ?>
      <?php
      $sql = "SELECT * FROM movies WHERE genre='$selected_genre' ORDER BY uploaded_at DESC";
      $result = $conn->query($sql);
      $movie_count = $result ? $result->num_rows : 0;
      ?>
      
      <div class="stats-bar">
        <div class="stats-item">
          <i class="fas fa-film"></i>
          <span><?php echo $movie_count; ?> movies found in <?php echo $selected_genre; ?></span>
        </div>
        <div class="stats-item">
          <i class="fas fa-exclamation-triangle"></i>
          <span>Deleting a movie is permanent and cannot be undone</span>
        </div>
      </div>
      
      <div class="movie-container">
        <?php
        if ($result && $result->num_rows > 0) {
          $animation_delay = 0;
          while ($row = $result->fetch_assoc()) {
            echo "
            <div class='movie-card' style='animation-delay: " . ($animation_delay * 0.1) . "s;'>
              <img src='admin/thumbnails/{$row['thumbnail']}' alt='{$row['title']}' class='movie-poster'>
              <div class='movie-info'>
                <h3 class='movie-title'>{$row['title']}</h3>
                <div class='movie-meta'>
                  <span class='movie-genre'>{$row['genre']}</span>
                  <span>" . date('M j, Y', strtotime($row['uploaded_at'])) . "</span>
                </div>
                <form method='POST' class='delete-form' onsubmit='return confirm(\"Are you sure you want to delete \\\"{$row['title']}\\\"? This action cannot be undone.\");'>
                  <input type='hidden' name='delete_id' value='{$row['id']}'>
                  <input type='hidden' name='genre' value='{$selected_genre}'>
                  <button type='submit' class='btn btn-danger'>
                    <i class='fas fa-trash-alt'></i> Delete Movie
                  </button>
                </form>
              </div>
            </div>";
            $animation_delay++;
          }
        } else {
          echo "
          <div class='no-movies'>
            <i class='fas fa-film'></i>
            <h3>No movies found</h3>
            <p>There are no movies in the <strong>$selected_genre</strong> genre.</p>
          </div>";
        }
        ?>
      </div>
    <?php else: ?>
      <div class="no-movies">
        <i class="fas fa-filter"></i>
        <h3>Select a genre to view movies</h3>
        <p>Choose a genre from the dropdown above to see available movies.</p>
      </div>
    <?php endif; ?>
  </div>
</div>

<script>
  // Add confirmation for delete actions
  document.addEventListener('DOMContentLoaded', function() {
    const deleteForms = document.querySelectorAll('.delete-form');
    
    deleteForms.forEach(form => {
      form.addEventListener('submit', function(e) {
        const movieTitle = this.closest('.movie-card').querySelector('.movie-title').textContent;
        if (!confirm(`Are you sure you want to delete "${movieTitle}"? This action cannot be undone.`)) {
          e.preventDefault();
        }
      });
    });
  });
</script>

</body>
</html>