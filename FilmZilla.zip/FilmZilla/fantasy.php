<?php 
include 'db.php';

// Handle download request
if (isset($_GET['download'])) {
    $file = basename($_GET['download']);
    $filepath = "admin/admin/uploads/" . $file; // Consistent with other pages

    if (file_exists($filepath)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($filepath) . '"');
        header('Content-Length: ' . filesize($filepath));
        readfile($filepath);
        exit;
    } else {
        echo "<p style='color:red; text-align:center;'>❌ File not found!</p>";
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fantasy Movies - FilmZilla</title>
    <style>
        :root {
            --primary-color: #1e3c72;
            --secondary-color: #2a5298;
            --accent-color: #ff6b6b;
            --card-bg: rgba(255, 255, 255, 0.1);
            --hover-bg: rgba(255, 255, 255, 0.25);
            --text-color: #fff;
            --shadow: 0 10px 20px rgba(0, 0, 0, 0.3);
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: var(--text-color);
            margin: 0;
            padding: 0;
            min-height: 100vh;
            position: relative;
            overflow-x: hidden;
        }
        
        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
                radial-gradient(circle at 10% 20%, rgba(255, 255, 255, 0.05) 0%, transparent 20%),
                radial-gradient(circle at 90% 80%, rgba(255, 255, 255, 0.05) 0%, transparent 20%);
            z-index: -1;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        header {
            text-align: center;
            padding: 40px 20px 30px;
            position: relative;
        }
        
        header::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 150px;
            height: 4px;
            background: linear-gradient(to right, transparent, var(--accent-color), transparent);
            border-radius: 2px;
        }
        
        h1 {
            font-size: 2.8rem;
            margin: 0;
            font-weight: 800;
            letter-spacing: 2px;
            text-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
            background: linear-gradient(to right, #fff, #e0e0e0);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 10px;
        }
        
        .subtitle {
            font-size: 1.2rem;
            margin: 0;
            opacity: 0.9;
            letter-spacing: 1px;
        }
        
        .back-link {
            display: inline-block;
            margin-top: 20px;
            color: var(--text-color);
            text-decoration: none;
            font-weight: 600;
            padding: 10px 20px;
            border-radius: 30px;
            background: rgba(255, 255, 255, 0.1);
            transition: all 0.3s ease;
        }
        
        .back-link:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateY(-3px);
        }
        
        .movie-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 30px;
            padding: 40px 0;
        }
        
        .movie-card {
            background: var(--card-bg);
            border-radius: 15px;
            overflow: hidden;
            text-align: center;
            cursor: pointer;
            transition: all 0.4s ease;
            box-shadow: var(--shadow);
            position: relative;
            z-index: 1;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .movie-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.1), transparent);
            z-index: -1;
            transition: opacity 0.4s;
            opacity: 0;
        }
        
        .movie-card:hover {
            background: var(--hover-bg);
            transform: translateY(-10px) scale(1.03);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.4);
        }
        
        .movie-card:hover::before {
            opacity: 1;
        }
        
        .movie-card::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 4px;
            background: var(--accent-color);
            transform: scaleX(0);
            transition: transform 0.4s ease;
        }
        
        .movie-card:hover::after {
            transform: scaleX(1);
        }
        
        .movie-poster {
            width: 100%;
            height: 350px;
            object-fit: cover;
            display: block;
        }
        
        .movie-info {
            padding: 20px 15px;
        }
        
        .movie-title {
            margin: 0 0 15px;
            font-size: 1.3rem;
            font-weight: 600;
            line-height: 1.4;
        }
        
        .download-btn {
            display: inline-block;
            background: var(--accent-color);
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 30px;
            cursor: pointer;
            font-weight: 600;
            font-size: 1rem;
            transition: all 0.3s ease;
            text-decoration: none;
            box-shadow: 0 4px 10px rgba(255, 107, 107, 0.3);
        }
        
        .download-btn:hover {
            background: #ff5252;
            transform: translateY(-3px);
            box-shadow: 0 6px 15px rgba(255, 107, 107, 0.4);
        }
        
        .no-movies {
            text-align: center;
            grid-column: 1 / -1;
            padding: 60px 20px;
            font-size: 1.3rem;
            opacity: 0.8;
        }
        
        /* Animation for page load */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .movie-card {
            animation: fadeInUp 0.6s ease forwards;
            opacity: 0;
        }
        
        .movie-card:nth-child(1) { animation-delay: 0.1s; }
        .movie-card:nth-child(2) { animation-delay: 0.2s; }
        .movie-card:nth-child(3) { animation-delay: 0.3s; }
        .movie-card:nth-child(4) { animation-delay: 0.4s; }
        .movie-card:nth-child(5) { animation-delay: 0.5s; }
        .movie-card:nth-child(6) { animation-delay: 0.6s; }
        .movie-card:nth-child(7) { animation-delay: 0.7s; }
        .movie-card:nth-child(8) { animation-delay: 0.8s; }
        .movie-card:nth-child(9) { animation-delay: 0.9s; }
        .movie-card:nth-child(10) { animation-delay: 1s; }
        
        /* Responsive adjustments */
        @media (max-width: 768px) {
            h1 {
                font-size: 2.2rem;
            }
            
            .subtitle {
                font-size: 1.1rem;
            }
            
            .movie-container {
                grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
                gap: 20px;
                padding: 30px 0;
            }
            
            .movie-poster {
                height: 280px;
            }
            
            .movie-info {
                padding: 15px 10px;
            }
            
            .movie-title {
                font-size: 1.2rem;
                margin-bottom: 12px;
            }
        }
        
        @media (max-width: 480px) {
            h1 {
                font-size: 1.8rem;
            }
            
            .subtitle {
                font-size: 1rem;
            }
            
            .movie-container {
                grid-template-columns: repeat(2, 1fr);
                gap: 15px;
            }
            
            .movie-poster {
                height: 220px;
            }
            
            .movie-info {
                padding: 12px 8px;
            }
            
            .movie-title {
                font-size: 1rem;
                margin-bottom: 10px;
            }
            
            .download-btn {
                padding: 10px 18px;
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>🧙‍♂️ Fantasy Movies</h1>
            <p class="subtitle">Magical worlds and mythical adventures</p>
            <a href="index.html" class="back-link">← Back to Genres</a>
        </header>

        <div class="movie-container">
            <?php
            $sql = "SELECT * FROM movies WHERE genre='Fantasy' ORDER BY uploaded_at DESC";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    // Use consistent paths with other pages
                    $thumb = "admin/admin/thumbnails/" . $row['thumbnail'];
                    $file = $row['file_path'];

                    echo "
                    <div class='movie-card'>
                        <img src='$thumb' alt='{$row['title']}' class='movie-poster'>
                        <div class='movie-info'>
                            <h3 class='movie-title'>{$row['title']}</h3>
                            <a href='fantasy.php?download=$file' class='download-btn'>⬇️ Download Now</a>
                        </div>
                    </div>";
                }
            } else {
                echo "<div class='no-movies'>No Fantasy movies available at the moment.</div>";
            }
            ?>
        </div>
    </div>
</body>
</html>