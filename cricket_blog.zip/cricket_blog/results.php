<?php
include "includes/db.php";

// Set character encoding
mysqli_set_charset($connect, "utf8");

// Get all match results
$query = "SELECT * FROM match_results ORDER BY match_date DESC";
$result = mysqli_query($connect, $query);

if (!$result) {
    die("Database query failed: " . mysqli_error($connect));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cricket Match Results</title>
    <style>
        /* Add this new style for match format badge */
        .match-format {
            background: #007bff;
            color: white;
            padding: 4px 12px;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: bold;
            margin-left: 10px;
        }
        
        /* Rest of your existing CSS remains the same */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .header {
            text-align: center;
            margin-bottom: 40px;
            color: white;
        }
        
        .header h1 {
            font-size: 3rem;
            margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        
        .matches-grid {
            display: grid;
            gap: 25px;
            margin-bottom: 40px;
        }
        
        .match-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            border-left: 5px solid #e74c3c;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .match-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0,0,0,0.3);
        }
        
        .match-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f8f9fa;
        }
        
        .match-date {
            color: #6c757d;
            font-size: 0.9rem;
            font-weight: 500;
        }
        
        .match-status {
            background: #28a745;
            color: white;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: bold;
        }
        
        .teams-container {
            display: grid;
            grid-template-columns: 1fr auto 1fr;
            gap: 20px;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .team {
            text-align: center;
        }
        
        .team-name {
            font-size: 1.4rem;
            font-weight: bold;
            margin-bottom: 10px;
            color: #2c3e50;
        }
        
        .team-score {
            font-size: 2.5rem;
            font-weight: bold;
            color: #e74c3c;
        }
        
        .vs {
            font-size: 1.2rem;
            color: #6c757d;
            font-weight: bold;
        }
        
        .match-result {
            text-align: center;
            margin: 20px 0;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 10px;
            border-left: 4px solid #28a745;
        }
        
        .winner {
            font-size: 1.3rem;
            font-weight: bold;
            color: #28a745;
            margin-bottom: 5px;
        }
        
        .match-summary {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            margin-top: 15px;
        }
        
        .summary-title {
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 10px;
            font-size: 1.1rem;
        }
        
        .summary-content {
            color: #555;
            line-height: 1.6;
        }
        
        .no-matches {
            text-align: center;
            padding: 60px 40px;
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        
        .back-button {
            display: inline-block;
            background-color: white;
            color: #667eea;
            padding: 12px 25px;
            text-decoration: none;
            border-radius: 25px;
            font-weight: bold;
            margin-bottom: 30px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        
        .back-button:hover {
            background-color: #f8f9fa;
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0,0,0,0.15);
        }
        
        /* Responsive design */
        @media (max-width: 768px) {
            .teams-container {
                grid-template-columns: 1fr;
                gap: 15px;
            }
            
            .vs {
                order: -1;
            }
            
            .header h1 {
                font-size: 2.2rem;
            }
            
            .team-score {
                font-size: 2rem;
            }
            
            .match-card {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="index.php" class="back-button">← Back to Home</a>
        
        <div class="header">
            <h1>🏏 Cricket Match Results</h1>
            <p>Latest match scores and summaries</p>
        </div>

        <?php if(mysqli_num_rows($result) > 0): ?>
            <div class="matches-grid">
                <?php while($match = mysqli_fetch_assoc($result)): ?>
                    <div class="match-card">
                        <div class="match-header">
                            <div class="match-date">
                                <?php echo date('F j, Y - g:i A', strtotime($match['match_date'])); ?>
                                <span class="match-format"><?php echo htmlspecialchars($match['match_format']); ?></span>
                            </div>
                            <div class="match-status">Completed</div>
                        </div>
                        
                        <div class="teams-container">
                            <div class="team">
                                <div class="team-name"><?php echo htmlspecialchars($match['team_a']); ?></div>
                                <div class="team-score"><?php echo htmlspecialchars($match['score_a']); ?></div>
                            </div>
                            
                            <div class="vs">VS</div>
                            
                            <div class="team">
                                <div class="team-name"><?php echo htmlspecialchars($match['team_b']); ?></div>
                                <div class="team-score"><?php echo htmlspecialchars($match['score_b']); ?></div>
                            </div>
                        </div>
                        
                        <div class="match-result">
                            <div class="winner">🏆 <?php echo htmlspecialchars($match['winner']); ?></div>
                        </div>
                        
                        <div class="match-summary">
                            <div class="summary-title">Match Summary</div>
                            <div class="summary-content"><?php echo nl2br(htmlspecialchars($match['summary'])); ?></div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <div class="no-matches">
                <h3>No Match Results Available</h3>
                <p>Add match results to see them displayed here.</p>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>