Change db.php port 3308 to your one.
For admin username=admin,password=1234
the spaces in left and right sides of index.php is considered for web ads, that's how normal pages work

first create a db called cricket_blog 