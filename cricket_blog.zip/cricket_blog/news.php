<?php
include "includes/db.php";

// Set character encoding for database connection
mysqli_set_charset($connect, "utf8");

// Get the base directory for proper path resolution
$base_dir = __DIR__;
$uploads_dir = $base_dir . "/uploads/";

// Pagination setup
$limit = 4; // 4 news per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;
$start = ($page - 1) * $limit;

// Date filter
$filter_date = isset($_GET['date']) ? mysqli_real_escape_string($connect, $_GET['date']) : '';

// Build query
$query = "SELECT * FROM news";
if($filter_date){
    $query .= " WHERE DATE(created_at) = '$filter_date'";
}
$query .= " ORDER BY created_at DESC LIMIT $start, $limit";

$result = mysqli_query($connect, $query);

// Get total rows for pagination
$count_query = "SELECT COUNT(*) as total FROM news";
if($filter_date){
    $count_query .= " WHERE DATE(created_at) = '$filter_date'";
}
$total_rows = mysqli_fetch_assoc(mysqli_query($connect, $count_query))['total'];
$total_pages = ceil($total_rows / $limit);

// Ensure page doesn't exceed total pages
if ($page > $total_pages && $total_pages > 0) {
    $page = $total_pages;
    $start = ($page - 1) * $limit;
    // Re-run query with corrected page
    $query = "SELECT * FROM news";
    if($filter_date){
        $query .= " WHERE DATE(created_at) = '$filter_date'";
    }
    $query .= " ORDER BY created_at DESC LIMIT $start, $limit";
    $result = mysqli_query($connect, $query);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>News</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            padding: 20px;
            background-color: #f5f5f5;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }
        
        .filter-form {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
        
        .filter-form input[type="date"] {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        
        .filter-form button {
            padding: 8px 16px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
        }
        
        .filter-form button:hover {
            background-color: #0056b3;
        }
        
        .news-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .news-box {
            background: white;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border: 1px solid #e0e0e0;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            display: flex;
            flex-direction: column;
            height: 100%;
        }
        
        .news-box:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.15);
        }
        
        .news-box h3 {
            margin: 0 0 10px 0;
            color: #333;
            font-size: 18px;
            line-height: 1.4;
        }
        
        .news-image {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 4px;
            margin-bottom: 10px;
            background-color: #f8f9fa;
        }
        
        .image-placeholder {
            width: 100%;
            height: 200px;
            background-color: #f8f9fa;
            border-radius: 4px;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #6c757d;
            font-size: 14px;
            border: 1px dashed #dee2e6;
        }
        
        .news-date {
            color: #666;
            font-size: 12px;
            margin-bottom: 10px;
        }
        
        .news-description {
            color: #555;
            flex-grow: 1;
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
            gap: 8px;
            margin-top: 30px;
        }
        
        .pagination a, .pagination span {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 40px;
            height: 40px;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
            text-decoration: none;
            color: #007bff;
            transition: all 0.2s ease;
            font-size: 14px;
            font-weight: 500;
        }
        
        .pagination a:hover {
            background-color: #007bff;
            color: white;
            border-color: #007bff;
        }
        
        .pagination .current {
            background-color: #007bff;
            color: white;
            border-color: #007bff;
        }
        
        .pagination .disabled {
            color: #ccc;
            border-color: #eee;
            cursor: not-allowed;
        }
        
        .pagination .ellipsis {
            border: none;
            color: #666;
            cursor: default;
        }
        
        .no-news {
            text-align: center;
            padding: 40px;
            color: #666;
            font-size: 18px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        hr {
            margin: 20px 0;
            border: none;
            border-top: 1px solid #eee;
        }
        
        /* Responsive design */
        @media (max-width: 768px) {
            .news-grid {
                grid-template-columns: 1fr;
            }
            
            .container {
                padding: 10px;
            }
            
            .filter-form {
                flex-direction: column;
                align-items: center;
            }
            
            .filter-form input[type="date"],
            .filter-form button {
                width: 100%;
                max-width: 300px;
            }
            
            .pagination {
                gap: 5px;
            }
            
            .pagination a, .pagination span {
                min-width: 35px;
                height: 35px;
                font-size: 13px;
            }
        }
        
        @media (max-width: 480px) {
            .news-grid {
                grid-template-columns: 1fr;
            }
            
            .news-box {
                padding: 15px;
            }
            
            .news-box h3 {
                font-size: 16px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>News</h2>
        <a href="index.php" class="back-button">← Back to Home</a>

        <!-- Date Filter -->
        <form method="GET" class="filter-form">
            <input type="hidden" name="page" value="1">
            <input type="date" name="date" value="<?php echo htmlspecialchars($filter_date); ?>">
            <button type="submit">Filter</button>
            <?php if($filter_date): ?>
                <a href="?" style="padding: 8px 16px; background-color: #6c757d; color: white; text-decoration: none; border-radius: 4px;">Clear Filter</a>
            <?php endif; ?>
        </form>

        <hr>

        <?php
        if(mysqli_num_rows($result) > 0){
            echo "<div class='news-grid'>";

            while($n = mysqli_fetch_assoc($result)){
                echo "<div class='news-box'>";
                echo "<h3>" . htmlspecialchars($n['title']) . "</h3>";

                // Debug: Check what's in the image field
                // echo "<!-- Debug: Image field value: " . htmlspecialchars($n['image']) . " -->";
                
                // Check if image exists and display it properly
                $image_name = $n['image'];
                $image_path = "uploads/" . $image_name;
                $full_image_path = $uploads_dir . $image_name;
                
                // Debug: Show the paths being checked
                // echo "<!-- Debug: Checking image at: " . htmlspecialchars($full_image_path) . " -->";
                // echo "<!-- Debug: File exists: " . (file_exists($full_image_path) ? 'YES' : 'NO') . " -->";
                
                if(!empty($image_name) && file_exists($full_image_path)){
                    echo "<img src='" . htmlspecialchars($image_path) . "' class='news-image' alt='" . htmlspecialchars($n['title']) . "'>";
                    // echo "<!-- Debug: Image displayed successfully -->";
                } else {
                    echo "<div class='image-placeholder'>";
                    if(empty($image_name)) {
                        echo "No Image";
                    } else {
                        echo "Image Not Found: " . htmlspecialchars($image_name);
                    }
                    echo "</div>";
                }

                echo "<small class='news-date'>" . date('d M Y H:i', strtotime($n['created_at'])) . "</small>";
                echo "<div class='news-description'>" . nl2br(htmlspecialchars($n['description'])) . "</div>";
                echo "</div>";
            }

            echo "</div>";
        } else {
            echo "<div class='no-news'>No news found.</div>";
        }
        ?>

        <!-- Pagination -->
        <?php if($total_pages > 1): ?>
        <div class="pagination">
            <?php
            // Previous button
            if ($page > 1) {
                $prev_url = "?page=" . ($page - 1);
                if($filter_date) $prev_url .= "&date=" . urlencode($filter_date);
                echo "<a href='$prev_url'>&laquo; Prev</a>";
            } else {
                echo "<span class='disabled'>&laquo; Prev</span>";
            }

            // Always show first page
            $url = "?page=1";
            if($filter_date) $url .= "&date=" . urlencode($filter_date);
            $class = ($page == 1) ? 'current' : '';
            echo "<a href='$url' class='$class'>1</a>";

            // Calculate page range to show
            $start_page = max(2, $page - 2);
            $end_page = min($total_pages - 1, $page + 2);

            // Show ellipsis after first page if needed
            if ($start_page > 2) {
                echo "<span class='ellipsis'>...</span>";
            }

            // Show page numbers
            for ($i = $start_page; $i <= $end_page; $i++) {
                $url = "?page=$i";
                if($filter_date) $url .= "&date=" . urlencode($filter_date);
                $class = ($i == $page) ? 'current' : '';
                echo "<a href='$url' class='$class'>$i</a>";
            }

            // Show ellipsis before last page if needed
            if ($end_page < $total_pages - 1) {
                echo "<span class='ellipsis'>...</span>";
            }

            // Always show last page if there is more than one page
            if ($total_pages > 1) {
                $url = "?page=$total_pages";
                if($filter_date) $url .= "&date=" . urlencode($filter_date);
                $class = ($page == $total_pages) ? 'current' : '';
                echo "<a href='$url' class='$class'>$total_pages</a>";
            }

            // Next button
            if ($page < $total_pages) {
                $next_url = "?page=" . ($page + 1);
                if($filter_date) $next_url .= "&date=" . urlencode($filter_date);
                echo "<a href='$next_url'>Next &raquo;</a>";
            } else {
                echo "<span class='disabled'>Next &raquo;</span>";
            }
            ?>
        </div>
        <?php endif; ?>
    </div>


</body>
</html>