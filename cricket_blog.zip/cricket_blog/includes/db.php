<?php
$connect = mysqli_connect("localhost","root","","cricket_blog",3308);
mysqli_set_charset($connect, "utf8mb4");
if(!$connect){
    die("DB Connection Failed");
}
?>
