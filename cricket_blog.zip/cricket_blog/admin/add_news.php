<?php
include "../includes/db.php";

if(isset($_POST['submit'])){

    // escape long text to prevent SQL issues
    $title = mysqli_real_escape_string($connect, $_POST['title']);
    $description = mysqli_real_escape_string($connect, $_POST['description']);

    // handle image upload to folder
    $image_name = null;
    if(isset($_FILES['image']) && $_FILES['image']['size'] > 0){
        $upload_dir = "../uploads/";
        
        // Create uploads directory if it doesn't exist
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        $file_name = $_FILES['image']['name'];
        $file_tmp = $_FILES['image']['tmp_name'];
        $file_size = $_FILES['image']['size'];
        $file_error = $_FILES['image']['error'];
        
        // Get file extension
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        
        // Allowed file types
        $allowed_ext = array('jpg', 'jpeg', 'png', 'gif', 'webp');
        
        // Check if file type is allowed
        if(in_array($file_ext, $allowed_ext)){
            // Check for upload errors
            if($file_error === 0){
                // Check file size (max 5MB)
                if($file_size <= 5000000){
                    // Generate unique file name to prevent overwrites
                    $new_file_name = uniqid('news_', true) . '.' . $file_ext;
                    $upload_path = $upload_dir . $new_file_name;
                    
                    // Move uploaded file
                    if(move_uploaded_file($file_tmp, $upload_path)){
                        $image_name = $new_file_name;
                    } else {
                        echo "Error: Failed to upload image.<br>";
                    }
                } else {
                    echo "Error: Image size too large. Maximum size is 5MB.<br>";
                }
            } else {
                echo "Error: File upload error.<br>";
            }
        } else {
            echo "Error: Invalid file type. Only JPG, JPEG, PNG, GIF, and WEBP are allowed.<br>";
        }
    }

    // insert into DB - store only the image file name
    $sql = "INSERT INTO news(title, description, image) 
            VALUES ('$title', '$description', '$image_name')";

    if(mysqli_query($connect, $sql)){
        echo "<div style='color: green; padding: 10px; background: #d4edda; border: 1px solid #c3e6cb; border-radius: 4px; margin: 10px 0;'>News Added Successfully!</div>";
    } else {
        echo "<div style='color: #721c24; padding: 10px; background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 4px; margin: 10px 0;'>Error: " . mysqli_error($connect) . "</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add News</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        
        .form-container {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            position: relative;
        }
        
        h2 {
            color: #333;
            margin-bottom: 20px;
            text-align: center;
        }
        
        textarea, input[type="file"] {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
            margin-bottom: 15px;
            resize: vertical;
        }
        
        textarea {
            min-height: 40px;
        }
        
        textarea[name="description"] {
            min-height: 120px;
        }
        
        button {
            background-color: #007bff;
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
            margin-bottom: 10px;
        }
        
        button:hover {
            background-color: #0056b3;
        }
        
        .file-info {
            font-size: 12px;
            color: #666;
            margin-top: -10px;
            margin-bottom: 15px;
        }
        
        .required {
            color: #e74c3c;
        }
        
        .back-button {
            display: inline-block;
            background-color: #6c757d;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 4px;
            font-size: 14px;
            margin-bottom: 20px;
            transition: background-color 0.2s;
        }
        
        .back-button:hover {
            background-color: #545b62;
            text-decoration: none;
            color: white;
        }
        
        .button-container {
            display: flex;
            gap: 10px;
            margin-top: 10px;
        }
        
        .button-container button,
        .button-container .back-button {
            flex: 1;
            text-align: center;
        }
    </style>
</head>
<body>
    <!-- Back Button -->
    <a href="dashboard.php" class="back-button">← Back to Dashboard</a>
    
    <div class="form-container">
        <h2>Add News Article</h2>
        
        <form method="POST" enctype="multipart/form-data">
            <div>
                <textarea name="title" placeholder="News title" required></textarea>
            </div>
            
            <div>
                <textarea name="description" placeholder="News description" required></textarea>
            </div>
            
            <div>
                <input type="file" name="image" accept="image/*">
                <div class="file-info">Supported formats: JPG, JPEG, PNG, GIF, WEBP (Max: 5MB)</div>
            </div>
            
            <div class="button-container">
                <button type="submit" name="submit">Publish News</button>
                <a href="dashboard.php" class="back-button" style="text-align: center; line-height: 40px;">Cancel</a>
            </div>
        </form>
    </div>
</body>
</html>