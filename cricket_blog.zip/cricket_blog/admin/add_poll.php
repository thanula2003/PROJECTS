<?php
include "../includes/db.php";

if(isset($_POST['submit'])){
    // Sanitize inputs
    $question = mysqli_real_escape_string($connect, $_POST['question']);
    $option_a = mysqli_real_escape_string($connect, $_POST['option_a']);
    $option_b = mysqli_real_escape_string($connect, $_POST['option_b']);
    $option_c = mysqli_real_escape_string($connect, $_POST['option_c']);
    $option_d = mysqli_real_escape_string($connect, $_POST['option_d']);
    $ends_at = mysqli_real_escape_string($connect, $_POST['ends_at']);
    
    $sql = "INSERT INTO polls(question, option_a, option_b, option_c, option_d, ends_at)
            VALUES('$question', '$option_a', '$option_b', '$option_c', '$option_d', '$ends_at')";
    
    if(mysqli_query($connect, $sql)){
        echo "<div style='color: green; padding: 10px; background: #d4edda; border: 1px solid #c3e6cb; border-radius: 4px; margin: 10px 0;'>Poll Created Successfully!</div>";
    } else {
        echo "<div style='color: #721c24; padding: 10px; background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 4px; margin: 10px 0;'>Error: " . mysqli_error($connect) . "</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Poll</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        
        .form-container {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        h2 {
            color: #333;
            margin-bottom: 20px;
            text-align: center;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }
        
        input {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        
        button {
            background-color: #007bff;
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
        }
        
        button:hover {
            background-color: #0056b3;
        }
        
        .back-button {
            display: inline-block;
            background-color: #6c757d;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 4px;
            font-size: 14px;
            margin-bottom: 20px;
        }
        
        .back-button:hover {
            background-color: #545b62;
        }
        
        .optional {
            color: #6c757d;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <a href="dashboard.php" class="back-button">← Back to Dashboard</a>
    
    <div class="form-container">
        <h2>Create New Poll</h2>
        
        <form method="POST">
            <div class="form-group">
                <label for="question">Poll Question <span style="color: red;">*</span></label>
                <input type="text" id="question" name="question" placeholder="Enter your poll question" required>
            </div>
            
            <div class="form-group">
                <label for="option_a">Option A <span style="color: red;">*</span></label>
                <input type="text" id="option_a" name="option_a" placeholder="First option" required>
            </div>
            
            <div class="form-group">
                <label for="option_b">Option B <span style="color: red;">*</span></label>
                <input type="text" id="option_b" name="option_b" placeholder="Second option" required>
            </div>
            
            <div class="form-group">
                <label for="option_c">Option C <span class="optional">(Optional)</span></label>
                <input type="text" id="option_c" name="option_c" placeholder="Third option">
            </div>
            
            <div class="form-group">
                <label for="option_d">Option D <span class="optional">(Optional)</span></label>
                <input type="text" id="option_d" name="option_d" placeholder="Fourth option">
            </div>
            
            <div class="form-group">
                <label for="ends_at">Poll End Date & Time <span style="color: red;">*</span></label>
                <input type="datetime-local" id="ends_at" name="ends_at" required>
            </div>
            
            <button type="submit" name="submit">Create Poll</button>
        </form>
    </div>

    <script>
        // Set default end date to 7 days from now
        const defaultEndDate = new Date();
        defaultEndDate.setDate(defaultEndDate.getDate() + 7);
        document.getElementById('ends_at').value = defaultEndDate.toISOString().slice(0, 16);
    </script>
</body>
</html>