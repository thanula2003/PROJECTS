<?php
include "../includes/db.php";

if(isset($_POST['submit'])){
    // Check if all required fields are set
    if(isset($_POST['team_a'], $_POST['team_b'], $_POST['score_a'], $_POST['score_b'], $_POST['winner'], $_POST['summary'], $_POST['match_date'], $_POST['match_format'])) {
        
        // Sanitize inputs
        $team_a = mysqli_real_escape_string($connect, $_POST['team_a']);
        $team_b = mysqli_real_escape_string($connect, $_POST['team_b']);
        $score_a = mysqli_real_escape_string($connect, $_POST['score_a']);
        $score_b = mysqli_real_escape_string($connect, $_POST['score_b']);
        $winner = mysqli_real_escape_string($connect, $_POST['winner']);
        $summary = mysqli_real_escape_string($connect, $_POST['summary']);
        $match_date = mysqli_real_escape_string($connect, $_POST['match_date']);
        $match_format = mysqli_real_escape_string($connect, $_POST['match_format']);
        
        $sql = "INSERT INTO match_results(team_a, team_b, score_a, score_b, winner, summary, match_date, match_format)
                VALUES('$team_a', '$team_b', '$score_a', '$score_b', '$winner', '$summary', '$match_date', '$match_format')";
        
        if(mysqli_query($connect, $sql)){
            echo "<div style='color: green; padding: 10px; background: #d4edda; border: 1px solid #c3e6cb; border-radius: 4px; margin: 10px 0;'>Match Result Added Successfully!</div>";
        } else {
            echo "<div style='color: #721c24; padding: 10px; background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 4px; margin: 10px 0;'>Error: " . mysqli_error($connect) . "</div>";
        }
    } else {
        echo "<div style='color: #856404; padding: 10px; background: #fff3cd; border: 1px solid #ffeaa7; border-radius: 4px; margin: 10px 0;'>Please fill all required fields.</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Match Result</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        
        .form-container {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        h2 {
            color: #333;
            margin-bottom: 20px;
            text-align: center;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }
        
        input, select, textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
            box-sizing: border-box;
        }
        
        textarea {
            min-height: 100px;
            resize: vertical;
        }
        
        button {
            background-color: #007bff;
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
            margin-top: 10px;
        }
        
        button:hover {
            background-color: #0056b3;
        }
        
        .back-button {
            display: inline-block;
            background-color: #6c757d;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 4px;
            font-size: 14px;
            margin-bottom: 20px;
        }
        
        .back-button:hover {
            background-color: #545b62;
            text-decoration: none;
            color: white;
        }
        
        .required {
            color: #e74c3c;
        }
        
        .error {
            color: #e74c3c;
            font-size: 12px;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <a href="dashboard.php" class="back-button">← Back to Dashboard</a>
    
    <div class="form-container">
        <h2>Add Cricket Match Result</h2>
        
        <form method="POST" id="matchForm">
            <div class="form-group">
                <label for="team_a">Team A <span class="required">*</span></label>
                <input type="text" id="team_a" name="team_a" placeholder="e.g., India" required>
            </div>
            
            <div class="form-group">
                <label for="team_b">Team B <span class="required">*</span></label>
                <input type="text" id="team_b" name="team_b" placeholder="e.g., Australia" required>
            </div>
            
            <div class="form-group">
                <label for="match_date">Match Date & Time <span class="required">*</span></label>
                <input type="datetime-local" id="match_date" name="match_date" required>
                <div class="error" id="dateError"></div>
            </div>
            
            <div class="form-group">
                <label for="match_format">Match Format <span class="required">*</span></label>
                <select id="match_format" name="match_format" required>
                    <option value="">Select Format</option>
                    <option value="Test Match">Test Match</option>
                    <option value="ODI">One Day International (ODI)</option>
                    <option value="T20I">T20 International</option>
                    <option value="T20">T20 League</option>
                    <option value="First Class">First Class</option>
                    <option value="List A">List A</option>
                </select>
            </div>
            
            <div class="form-group">
                <label for="score_a">Team A Score <span class="required">*</span></label>
                <input type="text" id="score_a" name="score_a" placeholder="e.g., 289/7 (50 overs)" required>
            </div>
            
            <div class="form-group">
                <label for="score_b">Team B Score <span class="required">*</span></label>
                <input type="text" id="score_b" name="score_b" placeholder="e.g., 290/5 (48.3 overs)" required>
            </div>
            
            <div class="form-group">
                <label for="winner">Winner <span class="required">*</span></label>
                <input type="text" id="winner" name="winner" placeholder="e.g., Australia won by 5 wickets" required>
            </div>
            
            <div class="form-group">
                <label for="summary">Match Summary <span class="required">*</span></label>
                <textarea id="summary" name="summary" placeholder="Brief description of the match highlights..." required></textarea>
            </div>
            
            <button type="submit" name="submit">Save Match Result</button>
        </form>
    </div>

    <script>
        // Set default date to current date/time
        document.getElementById('match_date').value = new Date().toISOString().slice(0, 16);
        
        // Form validation
        document.getElementById('matchForm').addEventListener('submit', function(e) {
            let isValid = true;
            const matchDate = document.getElementById('match_date').value;
            const matchFormat = document.getElementById('match_format').value;
            const dateError = document.getElementById('dateError');
            
            // Reset error
            dateError.textContent = '';
            
            // Validate date is not in the future
            const selectedDate = new Date(matchDate);
            const now = new Date();
            
            if (selectedDate > now) {
                dateError.textContent = 'Match date cannot be in the future';
                isValid = false;
            }
            
            // Validate match format is selected
            if (!matchFormat) {
                isValid = false;
            }
            
            if (!isValid) {
                e.preventDefault();
            }
        });
    </script>
</body>
</html>