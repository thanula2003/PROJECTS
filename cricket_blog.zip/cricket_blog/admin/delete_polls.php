<?php
include "../includes/db.php";

// Delete Action
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    mysqli_query($connect, "DELETE FROM polls WHERE id = $id");
    header("Location: delete_polls.php?msg=deleted");
    exit;
}

// Fetch All Polls
$result = mysqli_query($connect, "SELECT * FROM polls ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Polls</title>

    <style>
        body {
            margin: 0;
            padding: 20px;
            background: #f4f6f9;
            font-family: Arial, sans-serif;
        }

        h2 {
            text-align: center;
            color: #046A38;
            margin-bottom: 20px;
        }

        .msg {
            text-align: center;
            color: green;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .table-wrapper {
            width: 95%;
            margin: auto;
            overflow-x: auto;
        }

        table {
            width: 100%;
            background: white;
            border-collapse: collapse;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
        }

        th, td {
            padding: 12px 10px;
            border-bottom: 1px solid #ddd;
            text-align: center;
        }

        th {
            background: #046A38;
            color: white;
            font-size: 15px;
        }

        tr:hover {
            background: #f1f1f1;
        }

        .delete-btn {
            background: #d00000;
            color: #fff;
            padding: 7px 15px;
            border-radius: 5px;
            font-size: 13px;
            text-decoration: none;
            transition: 0.2s ease-in-out;
        }

        .delete-btn:hover {
            background: #a30000;
        }

        .status-active {
            background: #0a7f2e;
            color: white;
            padding: 4px 10px;
            border-radius: 4px;
            font-size: 13px;
            font-weight: bold;
        }

        .status-ended {
            background: #777;
            color: white;
            padding: 4px 10px;
            border-radius: 4px;
            font-size: 13px;
            font-weight: bold;
        }

    </style>
</head>
<body>

<h2>Manage Polls</h2>
<a href="dashboard.php" class="back-button">← Back to Dashboard</a>


<?php if (isset($_GET['msg'])) { ?>
    <div class="msg">Poll deleted successfully!</div>
<?php } ?>

<div class="table-wrapper">
<table>
    <tr>
        <th>ID</th>
        <th>Question</th>
        <th>Option A</th>
        <th>Option B</th>
        <th>Option C</th>
        <th>Option D</th>
        <th>Status</th>
        <th>Ends At</th>
        <th>Action</th>
    </tr>

    <?php while ($row = mysqli_fetch_assoc($result)) { ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= htmlspecialchars($row['question']) ?></td>
            <td><?= $row['option_a'] ?></td>
            <td><?= $row['option_b'] ?></td>
            <td><?= $row['option_c'] ?: '-' ?></td>
            <td><?= $row['option_d'] ?: '-' ?></td>

            <td>
                <?php if ($row['status'] == "active") { ?>
                    <span class="status-active">Active</span>
                <?php } else { ?>
                    <span class="status-ended">Ended</span>
                <?php } ?>
            </td>

            <td><?= date("Y-m-d H:i", strtotime($row['ends_at'])) ?></td>

            <td>
                <a href="delete_polls.php?delete=<?= $row['id'] ?>"
                   class="delete-btn"
                   onclick="return confirm('Are you sure you want to delete this poll?');">
                   Delete
                </a>
            </td>
        </tr>
    <?php } ?>
</table>
</div>

</body>
</html>
