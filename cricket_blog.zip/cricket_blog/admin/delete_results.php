<?php
include "../includes/db.php";

// Delete action
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    mysqli_query($connect, "DELETE FROM match_results WHERE id = $id");
    header("Location: delete_results.php?msg=deleted");
    exit;
}

// Fetch data
$query = mysqli_query($connect, "SELECT * FROM match_results ORDER BY match_date DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Match Results</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f9;
            margin: 0;
            padding: 20px;
        }

        h2 {
            text-align: center;
            color: #046A38;
        }

        .table-wrapper {
            width: 95%;
            margin: auto;
            overflow-x: auto;
            margin-top: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        th, td {
            padding: 12px 10px;
            border-bottom: 1px solid #ddd;
            text-align: center;
        }

        th {
            background: #046A38;
            color: white;
            font-size: 16px;
        }

        tr:hover {
            background: #f2f2f2;
        }

        .delete-btn {
            background: #d00000;
            color: white;
            padding: 7px 14px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 14px;
            transition: 0.2s;
        }

        .delete-btn:hover {
            background: #a30000;
        }

        .msg {
            text-align: center;
            color: green;
            font-weight: bold;
            margin-bottom: 10px;
        }

    </style>
</head>
<body>

<h2>Manage Match Results</h2>
<a href="dashboard.php" class="back-button">← Back to Dashboard</a>

<?php if (isset($_GET['msg'])) { ?>
    <p class="msg">Record deleted successfully!</p>
<?php } ?>

<div class="table-wrapper">
<table>
    <tr>
        <th>ID</th>
        <th>Team A</th>
        <th>Team B</th>
        <th>Score A</th>
        <th>Score B</th>
        <th>Winner</th>
        <th>Format</th>
        <th>Match Date</th>
        <th>Summary</th>
        <th>Action</th>
    </tr>

    <?php while ($row = mysqli_fetch_assoc($query)) { ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= $row['team_a'] ?></td>
            <td><?= $row['team_b'] ?></td>
            <td><?= $row['score_a'] ?></td>
            <td><?= $row['score_b'] ?></td>
            <td><?= $row['winner'] ?></td>
            <td><?= $row['match_format'] ?></td>
            <td><?= date("Y-m-d H:i", strtotime($row['match_date'])) ?></td>
            <td><?= substr($row['summary'], 0, 40) ?>...</td>
            <td>
                <a class="delete-btn"
                   href="delete_results.php?delete=<?= $row['id'] ?>"
                   onclick="return confirm('Are you sure you want to delete this match result?');">
                   Delete
                </a>
            </td>
        </tr>
    <?php } ?>

</table>
</div>

</body>
</html>
