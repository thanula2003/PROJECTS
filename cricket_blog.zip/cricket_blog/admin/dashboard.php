
<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>

    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f3f6fa;
        }

        .header {
            background: #046A38; /* Cricket green */
            color: white;
            padding: 20px;
            text-align: center;
            font-size: 28px;
            font-weight: bold;
            letter-spacing: 1px;
        }

        .container {
            width: 90%;
            max-width: 900px;
            margin: 40px auto;
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
        }

        .card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            transition: 0.3s ease;
            cursor: pointer;
            border-left: 6px solid #046A38;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 18px rgba(0,0,0,0.15);
        }

        .card a {
            text-decoration: none;
            color: #046A38;
            font-size: 18px;
            font-weight: bold;
        }

        .section-title {
            margin: 30px 0 15px;
            font-size: 22px;
            color: #333;
            border-left: 5px solid #046A38;
            padding-left: 10px;
        }
        .btn {
            display: inline-block;
            background:rgb(213, 255, 235);
            color: white;
            padding: 12px 18px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 16px;
            font-weight: bold;
            transition: 0.25s ease;
        }

        .btn:hover {
            background:rgb(172, 231, 203);
            transform: scale(1.05);
        }


    </style>
</head>
<body>

    <div class="header">Cricket Blog Admin Dashboard</div>

    <div class="container">

    <h3 class="section-title">Add New Content</h3>
<div class="grid">
    <div class="card">
        <a href="add_news.php" class="btn">➕ Add News</a>
    </div>

    <div class="card">
        <a href="add_result.php" class="btn">🏏 Add Match Result</a>
    </div>

    <div class="card">
        <a href="add_poll.php" class="btn">📊 Create Poll</a>
    </div>
</div>

<h3 class="section-title">Manage Existing Content</h3>
<div class="grid">
    <div class="card">
        <a href="delete_news.php" class="btn">📰 Manage News</a>
    </div>

    <div class="card">
        <a href="delete_results.php" class="btn">📋 Manage Match Results</a>
    </div>

    <div class="card">
        <a href="delete_polls.php" class="btn">🗳 Manage Polls</a>
    </div>
</div>


 

</body>
</html>
