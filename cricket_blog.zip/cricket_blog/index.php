<?php
include "includes/db.php";

// Set character encoding
mysqli_set_charset($connect, "utf8");

// Handle new post submission
if(isset($_POST['submit_post'])) {
    $user_name = mysqli_real_escape_string($connect, $_POST['user_name']);
    $post_content = mysqli_real_escape_string($connect, $_POST['post_content']);
    
    // Handle image upload
    $post_image = null;
    if(isset($_FILES['post_image']) && $_FILES['post_image']['size'] > 0) {
        $upload_dir = "uploads/posts/";
        
        // Create uploads directory if it doesn't exist
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        $file_name = $_FILES['post_image']['name'];
        $file_tmp = $_FILES['post_image']['tmp_name'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        
        $allowed_ext = array('jpg', 'jpeg', 'png', 'gif', 'webp');
        
        if(in_array($file_ext, $allowed_ext)) {
            $new_file_name = uniqid('post_', true) . '.' . $file_ext;
            $upload_path = $upload_dir . $new_file_name;
            
            if(move_uploaded_file($file_tmp, $upload_path)) {
                $post_image = $new_file_name;
            }
        }
    }
    
    $sql = "INSERT INTO user_posts (user_name, post_content, post_image) 
            VALUES ('$user_name', '$post_content', '$post_image')";
    
    if(mysqli_query($connect, $sql)) {
        $success_message = "Post published successfully!";
    } else {
        $error_message = "Error: " . mysqli_error($connect);
    }
}

// Get latest posts
$posts_query = "SELECT * FROM user_posts ORDER BY created_at DESC LIMIT 10";
$posts_result = mysqli_query($connect, $posts_query);

// Get latest match results (limit 5)
$matches_query = "SELECT * FROM match_results ORDER BY match_date DESC LIMIT 5";
$matches_result = mysqli_query($connect, $matches_query);

// Get latest news (limit 5)
$news_query = "SELECT * FROM news ORDER BY created_at DESC LIMIT 5";
$news_result = mysqli_query($connect, $news_query);

// Get most recent active poll
$poll_query = "SELECT * FROM polls WHERE ends_at > NOW() ORDER BY created_at DESC LIMIT 1";
$poll_result = mysqli_query($connect, $poll_query);
$active_poll = mysqli_fetch_assoc($poll_result);

// Get user IP for vote tracking
$voter_ip = $_SERVER['REMOTE_ADDR'];

// Handle poll vote submission
if(isset($_POST['vote_poll_submit'])) {
    $poll_id = (int)$_POST['poll_id'];
    $voted_option = $_POST['vote_option'];
    
    // Check if user already voted
    $vote_check = mysqli_query($connect, "SELECT * FROM poll_votes WHERE poll_id = $poll_id AND voter_ip = '$voter_ip'");
    
    if(mysqli_num_rows($vote_check) == 0) {
        // Record the vote
        mysqli_query($connect, "INSERT INTO poll_votes (poll_id, voter_ip, voted_option) VALUES ($poll_id, '$voter_ip', '$voted_option')");
        $poll_success = "Thank you for voting!";
        
        // Refresh poll data
        $poll_result = mysqli_query($connect, $poll_query);
        $active_poll = mysqli_fetch_assoc($poll_result);
    } else {
        $poll_error = "You have already voted in this poll!";
    }
}

// Get vote counts for active poll if exists
if($active_poll) {
    $poll_id = $active_poll['id'];
    $user_voted = mysqli_query($connect, "SELECT * FROM poll_votes WHERE poll_id = $poll_id AND voter_ip = '$voter_ip'");
    $has_voted = mysqli_num_rows($user_voted) > 0;
    
    $votes_a = mysqli_fetch_assoc(mysqli_query($connect, "SELECT COUNT(*) as count FROM poll_votes WHERE poll_id = $poll_id AND voted_option = 'a'"))['count'];
    $votes_b = mysqli_fetch_assoc(mysqli_query($connect, "SELECT COUNT(*) as count FROM poll_votes WHERE poll_id = $poll_id AND voted_option = 'b'"))['count'];
    $votes_c = mysqli_fetch_assoc(mysqli_query($connect, "SELECT COUNT(*) as count FROM poll_votes WHERE poll_id = $poll_id AND voted_option = 'c'"))['count'];
    $votes_d = mysqli_fetch_assoc(mysqli_query($connect, "SELECT COUNT(*) as count FROM poll_votes WHERE poll_id = $poll_id AND voted_option = 'd'"))['count'];
    
    $total_votes = $votes_a + $votes_b + $votes_c + $votes_d;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cricket Community - Share Your Passion</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            background-color: #f0f2f5;
            color: #1c1e21;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            display: grid;
            grid-template-columns: 280px 1fr 280px;
            gap: 20px;
        }
        
        /* Header Styles */
        .header {
            grid-column: 1 / -1;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 15px;
            margin-bottom: 20px;
            text-align: center;
        }
        
        .header h1 {
            font-size: 2.5rem;
            margin-bottom: 10px;
        }
        
        .header p {
            font-size: 1.1rem;
            opacity: 0.9;
        }
        
        /* Compact Poll Section Styles */
        .poll-section {
            grid-column: 1 / -1;
            background: white;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            border-left: 4px solid #ff6b35;
        }
        
        .poll-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .poll-title {
            font-size: 1.1rem;
            font-weight: bold;
            color: #2c3e50;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .poll-meta {
            text-align: right;
            font-size: 0.8rem;
            color: #6c757d;
        }
        
        .status-badge {
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 0.7rem;
            font-weight: bold;
        }
        
        .status-active {
            background: #28a745;
            color: white;
        }
        
        .poll-question {
            font-size: 1rem;
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 12px;
            line-height: 1.4;
        }
        
        .poll-options {
            margin-bottom: 15px;
        }
        
        .option-item {
            margin-bottom: 8px;
            padding: 10px 12px;
            border: 1px solid #e9ecef;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
        }
        
        .option-item:hover {
            border-color: #007bff;
            background-color: #f8f9fa;
        }
        
        .option-item.selected {
            border-color: #28a745;
            background-color: #d4edda;
        }
        
        .option-radio {
            margin-right: 10px;
            transform: scale(1.1);
        }
        
        .option-label {
            font-weight: 500;
            color: #495057;
            font-size: 0.9rem;
            flex-grow: 1;
        }
        
        .vote-button {
            background: #28a745;
            color: white;
            border: none;
            padding: 8px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.9rem;
            font-weight: 600;
            transition: background 0.3s ease;
        }
        
        .vote-button:hover {
            background: #218838;
        }
        
        .poll-results {
            margin-top: 15px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 6px;
        }
        
        .results-title {
            font-size: 0.9rem;
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 10px;
            text-align: center;
        }
        
        .result-item {
            margin-bottom: 10px;
        }
        
        .result-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 4px;
        }
        
        .result-option {
            font-weight: 500;
            color: #495057;
            font-size: 0.85rem;
        }
        
        .result-stats {
            font-weight: bold;
            color: #007bff;
            font-size: 0.8rem;
        }
        
        .result-bar {
            height: 20px;
            background: #e9ecef;
            border-radius: 10px;
            overflow: hidden;
            position: relative;
        }
        
        .result-fill {
            height: 100%;
            background: linear-gradient(90deg, #007bff, #0056b3);
            border-radius: 10px;
            transition: width 0.5s ease;
            min-width: 25px;
            display: flex;
            align-items: center;
            justify-content: flex-end;
            padding: 0 10px;
        }
        
        .result-percentage {
            color: white;
            font-weight: bold;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.5);
            font-size: 0.7rem;
        }
        
        .more-polls-link {
            display: block;
            text-align: center;
            padding: 8px;
            background: #f8f9fa;
            border-radius: 6px;
            color: #1877f2;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.85rem;
            margin-top: 12px;
            transition: background 0.3s ease;
        }
        
        .more-polls-link:hover {
            background: #e9ecef;
            text-decoration: none;
        }
        
        /* Sidebar Styles */
        .sidebar {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            height: fit-content;
        }
        
        .sidebar-title {
            font-size: 1.2rem;
            font-weight: bold;
            color: #1c1e21;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid #e4e6eb;
        }
        
        /* Main Content Styles */
        .main-content {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
        
        /* Post Box Styles */
        .post-box {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .post-form input, .post-form textarea {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border: 1px solid #dddfe2;
            border-radius: 8px;
            font-size: 14px;
            resize: vertical;
        }
        
        .post-form textarea {
            min-height: 100px;
        }
        
        .post-form button {
            background: #1877f2;
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
        }
        
        .post-form button:hover {
            background: #166fe5;
        }
        
        /* Posts Feed Styles */
        .posts-feed {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        
        .post-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .post-header {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            background: #1877f2;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            margin-right: 10px;
        }
        
        .user-info {
            flex-grow: 1;
        }
        
        .user-name {
            font-weight: bold;
            color: #1c1e21;
        }
        
        .post-time {
            font-size: 12px;
            color: #65676b;
        }
        
        .post-content {
            margin-bottom: 15px;
            line-height: 1.5;
        }
        
        .post-image {
            width: 100%;
            max-height: 400px;
            object-fit: cover;
            border-radius: 8px;
            margin-bottom: 15px;
        }
        
        /* Match Card Styles */
        .match-card {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 15px;
            border-left: 4px solid #28a745;
        }
        
        .match-teams {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 8px;
        }
        
        .team {
            font-weight: bold;
            font-size: 14px;
        }
        
        .team-score {
            font-size: 12px;
            color: #666;
        }
        
        .match-winner {
            font-size: 12px;
            color: #28a745;
            font-weight: bold;
        }
        
        .match-date {
            font-size: 11px;
            color: #999;
            margin-top: 5px;
        }
        
        /* News Card Styles */
        .news-card {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 15px;
            border-left: 4px solid #007bff;
        }
        
        .news-title {
            font-weight: bold;
            font-size: 14px;
            margin-bottom: 8px;
            color: #1c1e21;
        }
        
        .news-date {
            font-size: 11px;
            color: #999;
        }
        
        .see-more {
            display: block;
            text-align: center;
            padding: 10px;
            background: #f0f2f5;
            border-radius: 6px;
            color: #1877f2;
            text-decoration: none;
            font-weight: bold;
            margin-top: 10px;
        }
        
        .see-more:hover {
            background: #e4e6eb;
        }
        
        /* Message Styles */
        .message {
            padding: 10px 12px;
            border-radius: 6px;
            margin-bottom: 12px;
            font-size: 0.85rem;
        }
        
        .success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        /* Responsive Design */
        @media (max-width: 1024px) {
            .container {
                grid-template-columns: 1fr;
            }
            
            .sidebar {
                order: 3;
            }
        }
        
        @media (max-width: 768px) {
            .container {
                padding: 10px;
            }
            
            .header {
                padding: 20px;
            }
            
            .header h1 {
                font-size: 2rem;
            }
            
            .poll-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 8px;
            }
            
            .poll-meta {
                text-align: left;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <h1>🏏 Cricket Community</h1>
            <p>Share your thoughts, discuss matches, and connect with fellow cricket fans</p>
        </div>
        
        <!-- Compact Active Poll Section -->
        <?php if($active_poll): ?>
        <div class="poll-section">
            <div class="poll-header">
                <div class="poll-title">
                    📊 Quick Poll
                    <span class="status-badge status-active">Live</span>
                </div>
                <div class="poll-meta">
                    <div>Ends: <?php echo date('M j, g:i A', strtotime($active_poll['ends_at'])); ?></div>
                    <div><?php echo $total_votes; ?> votes</div>
                </div>
            </div>
            
            <div class="poll-question"><?php echo htmlspecialchars($active_poll['question']); ?></div>
            
            <?php if(isset($poll_success)): ?>
                <div class="message success"><?php echo $poll_success; ?></div>
            <?php endif; ?>
            
            <?php if(isset($poll_error)): ?>
                <div class="message error"><?php echo $poll_error; ?></div>
            <?php endif; ?>
            
            <?php if($has_voted): ?>
                <!-- Show compact results after voting -->
                <div class="poll-results">
                    <div class="results-title">Current Results</div>
                    <?php
                    $options = [
                        'a' => ['text' => $active_poll['option_a'], 'votes' => $votes_a],
                        'b' => ['text' => $active_poll['option_b'], 'votes' => $votes_b],
                        'c' => ['text' => $active_poll['option_c'], 'votes' => $votes_c],
                        'd' => ['text' => $active_poll['option_d'], 'votes' => $votes_d]
                    ];
                    
                    foreach($options as $key => $option):
                        if(!empty($option['text'])):
                            $votes = $option['votes'];
                            $percentage = $total_votes > 0 ? round(($votes / $total_votes) * 100, 1) : 0;
                    ?>
                        <div class="result-item">
                            <div class="result-header">
                                <span class="result-option"><?php echo htmlspecialchars($option['text']); ?></span>
                                <span class="result-stats"><?php echo $percentage; ?>%</span>
                            </div>
                            <div class="result-bar">
                                <div class="result-fill" style="width: <?php echo $percentage; ?>%;">
                                    <span class="result-percentage"><?php echo $percentage; ?>%</span>
                                </div>
                            </div>
                        </div>
                    <?php endif; endforeach; ?>
                </div>
            <?php else: ?>
                <!-- Show compact voting form -->
                <form method="POST" class="poll-options">
                    <input type="hidden" name="poll_id" value="<?php echo $active_poll['id']; ?>">
                    
                    <div class="option-item" onclick="selectOption(this, 'a')">
                        <input type="radio" class="option-radio" name="vote_option" value="a" id="option_a_main" required>
                        <label class="option-label" for="option_a_main"><?php echo htmlspecialchars($active_poll['option_a']); ?></label>
                    </div>
                    
                    <div class="option-item" onclick="selectOption(this, 'b')">
                        <input type="radio" class="option-radio" name="vote_option" value="b" id="option_b_main">
                        <label class="option-label" for="option_b_main"><?php echo htmlspecialchars($active_poll['option_b']); ?></label>
                    </div>
                    
                    <?php if(!empty($active_poll['option_c'])): ?>
                    <div class="option-item" onclick="selectOption(this, 'c')">
                        <input type="radio" class="option-radio" name="vote_option" value="c" id="option_c_main">
                        <label class="option-label" for="option_c_main"><?php echo htmlspecialchars($active_poll['option_c']); ?></label>
                    </div>
                    <?php endif; ?>
                    
                    <?php if(!empty($active_poll['option_d'])): ?>
                    <div class="option-item" onclick="selectOption(this, 'd')">
                        <input type="radio" class="option-radio" name="vote_option" value="d" id="option_d_main">
                        <label class="option-label" for="option_d_main"><?php echo htmlspecialchars($active_poll['option_d']); ?></label>
                    </div>
                    <?php endif; ?>
                    
                    <div style="text-align: center; margin-top: 10px;">
                        <button type="submit" name="vote_poll_submit" class="vote-button">Vote Now</button>
                    </div>
                </form>
            <?php endif; ?>
            
            <a href="polls.php" class="more-polls-link">More Polls →</a>
        </div>
        <?php endif; ?>
        
        <!-- Rest of the content remains the same -->
        <!-- Left Sidebar - Match Results -->
        <div class="sidebar">
            <div class="sidebar-title">📊 Recent Match Results</div>
            <?php if(mysqli_num_rows($matches_result) > 0): ?>
                <?php while($match = mysqli_fetch_assoc($matches_result)): ?>
                    <div class="match-card">
                        <div class="match-teams">
                            <div class="team"><?php echo htmlspecialchars($match['team_a']); ?></div>
                            <div class="team-score"><?php echo htmlspecialchars($match['score_a']); ?></div>
                        </div>
                        <div class="match-teams">
                            <div class="team"><?php echo htmlspecialchars($match['team_b']); ?></div>
                            <div class="team-score"><?php echo htmlspecialchars($match['score_b']); ?></div>
                        </div>
                        <div class="match-winner">🏆 <?php echo htmlspecialchars($match['winner']); ?></div>
                        <div class="match-date"><?php echo date('M j, Y', strtotime($match['match_date'])); ?></div>
                    </div>
                <?php endwhile; ?>
                <a href="results.php" class="see-more">See All Matches →</a>
            <?php else: ?>
                <p style="color: #666; text-align: center;">No match results available</p>
            <?php endif; ?>
        </div>
        
        <!-- Main Content - Posting Area -->
        <div class="main-content">
            <!-- Post Form -->
            <div class="post-box">
                <h3 style="margin-bottom: 15px;">Share your cricket thoughts</h3>
                
                <?php if(isset($success_message)): ?>
                    <div class="message success"><?php echo $success_message; ?></div>
                <?php endif; ?>
                
                <?php if(isset($error_message)): ?>
                    <div class="message error"><?php echo $error_message; ?></div>
                <?php endif; ?>
                
                <form method="POST" enctype="multipart/form-data" class="post-form">
                    <input type="text" name="user_name" placeholder="Your Name" required>
                    <textarea name="post_content" placeholder="What's on your mind about cricket?" required></textarea>
                    <input type="file" name="post_image" accept="image/*">
                    <button type="submit" name="submit_post">Publish Post</button>
                </form>
            </div>
            
            <!-- Posts Feed -->
            <div class="posts-feed">
                <h3 style="margin-bottom: 15px;">Recent Posts</h3>
                
                <?php if(mysqli_num_rows($posts_result) > 0): ?>
                    <?php while($post = mysqli_fetch_assoc($posts_result)): ?>
                        <div class="post-card">
                            <div class="post-header">
                                <div class="user-avatar">
                                    <?php echo strtoupper(substr($post['user_name'], 0, 1)); ?>
                                </div>
                                <div class="user-info">
                                    <div class="user-name"><?php echo htmlspecialchars($post['user_name']); ?></div>
                                    <div class="post-time"><?php echo date('F j, Y \a\t g:i A', strtotime($post['created_at'])); ?></div>
                                </div>
                            </div>
                            
                            <div class="post-content">
                                <?php echo nl2br(htmlspecialchars($post['post_content'])); ?>
                            </div>
                            
                            <?php if($post['post_image']): ?>
                                <img src="uploads/posts/<?php echo htmlspecialchars($post['post_image']); ?>" 
                                     alt="Post image" class="post-image">
                            <?php endif; ?>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="post-card" style="text-align: center; color: #666;">
                        <p>No posts yet. Be the first to share your thoughts!</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Right Sidebar - News -->
        <div class="sidebar">
            <div class="sidebar-title">📰 Latest Cricket News</div>
            <?php if(mysqli_num_rows($news_result) > 0): ?>
                <?php while($news = mysqli_fetch_assoc($news_result)): ?>
                    <div class="news-card">
                        <div class="news-title"><?php echo htmlspecialchars($news['title']); ?></div>
                        <div class="news-date"><?php echo date('M j, Y', strtotime($news['created_at'])); ?></div>
                    </div>
                <?php endwhile; ?>
                <a href="news.php" class="see-more">See All News →</a>
            <?php else: ?>
                <p style="color: #666; text-align: center;">No news available</p>
            <?php endif; ?>
        </div>
    </div>

    <script>
        function selectOption(element, value) {
            // Remove selected class from all options
            const options = element.parentElement.querySelectorAll('.option-item');
            options.forEach(opt => opt.classList.remove('selected'));
            
            // Add selected class to clicked option
            element.classList.add('selected');
            
            // Check the radio button
            const radio = element.querySelector('input[type="radio"]');
            radio.checked = true;
        }
        
        // Auto-select option when radio is clicked
        document.querySelectorAll('.option-radio').forEach(radio => {
            radio.addEventListener('click', function(e) {
                e.stopPropagation();
                selectOption(this.parentElement, this.value);
            });
        });
    </script>
</body>
</html>