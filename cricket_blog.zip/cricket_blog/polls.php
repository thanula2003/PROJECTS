<?php
include "includes/db.php";

// Set character encoding
mysqli_set_charset($connect, "utf8");

// Get user IP for vote tracking
$voter_ip = $_SERVER['REMOTE_ADDR'];

// Handle vote submission
if(isset($_POST['vote_submit'])) {
    $poll_id = (int)$_POST['poll_id'];
    $voted_option = $_POST['vote_option'];
    
    // Check if poll exists and is active (not ended)
    $poll_check = mysqli_query($connect, "SELECT * FROM polls WHERE id = $poll_id AND ends_at > NOW()");
    
    if(mysqli_num_rows($poll_check) > 0) {
        // Check if user already voted
        $vote_check = mysqli_query($connect, "SELECT * FROM poll_votes WHERE poll_id = $poll_id AND voter_ip = '$voter_ip'");
        
        if(mysqli_num_rows($vote_check) == 0) {
            // Record the vote
            mysqli_query($connect, "INSERT INTO poll_votes (poll_id, voter_ip, voted_option) VALUES ($poll_id, '$voter_ip', '$voted_option')");
            $vote_success = "Thank you for voting!";
        } else {
            $vote_error = "You have already voted in this poll!";
        }
    } else {
        $vote_error = "This poll has ended!";
    }
}

// Update poll status for ended polls - FIXED LOGIC
mysqli_query($connect, "UPDATE polls SET status = 'ended' WHERE ends_at <= NOW() AND status = 'active'");

// Get all polls with proper status checking
$polls_query = "SELECT *, 
                CASE 
                    WHEN ends_at <= NOW() THEN 'ended' 
                    ELSE 'active' 
                END as current_status 
                FROM polls 
                ORDER BY 
                CASE 
                    WHEN ends_at <= NOW() THEN 2 
                    ELSE 1 
                END, 
                created_at DESC";
$polls_result = mysqli_query($connect, $polls_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cricket Polls - Vote Now</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 800px;
            margin: 0 auto;
        }
        
        .header {
            text-align: center;
            margin-bottom: 40px;
            color: white;
        }
        
        .header h1 {
            font-size: 2.5rem;
            margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        
        .header p {
            font-size: 1.1rem;
            opacity: 0.9;
        }
        
        .back-button {
            display: inline-block;
            background-color: white;
            color: #667eea;
            padding: 12px 25px;
            text-decoration: none;
            border-radius: 25px;
            font-weight: bold;
            margin-bottom: 30px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        
        .back-button:hover {
            background-color: #f8f9fa;
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0,0,0,0.15);
        }
        
        .poll-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 25px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            border-left: 5px solid #007bff;
        }
        
        .poll-card.ended {
            border-left-color: #6c757d;
            opacity: 0.95;
        }
        
        .poll-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f8f9fa;
        }
        
        .poll-question {
            font-size: 1.3rem;
            font-weight: bold;
            color: #2c3e50;
            flex-grow: 1;
        }
        
        .poll-meta {
            text-align: right;
            font-size: 0.9rem;
            color: #6c757d;
        }
        
        .status-badge {
            padding: 4px 12px;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: bold;
            margin-left: 10px;
        }
        
        .status-active {
            background: #28a745;
            color: white;
        }
        
        .status-ended {
            background: #6c757d;
            color: white;
        }
        
        .poll-options {
            margin-bottom: 20px;
        }
        
        .option-item {
            margin-bottom: 12px;
            padding: 15px;
            border: 2px solid #e9ecef;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
        }
        
        .option-item:hover {
            border-color: #007bff;
            background-color: #f8f9fa;
        }
        
        .option-item.selected {
            border-color: #28a745;
            background-color: #d4edda;
        }
        
        .option-radio {
            margin-right: 15px;
            transform: scale(1.2);
        }
        
        .option-label {
            font-weight: 500;
            color: #495057;
        }
        
        .vote-button {
            background: #28a745;
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
            width: 100%;
            transition: background 0.3s ease;
        }
        
        .vote-button:hover {
            background: #218838;
        }
        
        .vote-button:disabled {
            background: #6c757d;
            cursor: not-allowed;
        }
        
        .poll-results {
            margin-top: 20px;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 8px;
        }
        
        .results-title {
            font-size: 1.1rem;
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 15px;
            text-align: center;
        }
        
        .result-item {
            margin-bottom: 15px;
        }
        
        .result-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 5px;
        }
        
        .result-option {
            font-weight: 500;
            color: #495057;
        }
        
        .result-stats {
            font-weight: bold;
            color: #007bff;
        }
        
        .result-bar {
            height: 30px;
            background: #e9ecef;
            border-radius: 15px;
            overflow: hidden;
            position: relative;
        }
        
        .result-fill {
            height: 100%;
            background: linear-gradient(90deg, #007bff, #0056b3);
            border-radius: 15px;
            transition: width 0.5s ease;
            min-width: 30px;
            display: flex;
            align-items: center;
            justify-content: flex-end;
            padding: 0 15px;
        }
        
        .result-percentage {
            color: white;
            font-weight: bold;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.5);
            font-size: 0.9rem;
        }
        
        .winner-badge {
            background: #28a745;
            color: white;
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 0.7rem;
            margin-left: 8px;
            font-weight: bold;
        }
        
        .message {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .no-polls {
            text-align: center;
            padding: 60px 40px;
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        
        .no-polls h3 {
            color: #6c757d;
            margin-bottom: 15px;
            font-size: 1.5rem;
        }
        
        .ended-message {
            text-align: center;
            padding: 20px;
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            border-radius: 8px;
            color: #856404;
            margin-bottom: 20px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="index.php" class="back-button">← Back to Home</a>
        
        <div class="header">
            <h1>📊 Cricket Polls</h1>
            <p>Vote on current cricket topics and see what others think</p>
        </div>

        <?php if(isset($vote_success)): ?>
            <div class="message success"><?php echo $vote_success; ?></div>
        <?php endif; ?>
        
        <?php if(isset($vote_error)): ?>
            <div class="message error"><?php echo $vote_error; ?></div>
        <?php endif; ?>

        <?php if(mysqli_num_rows($polls_result) > 0): ?>
            <?php 
            $active_polls_count = 0;
            $ended_polls_count = 0;
            ?>
            
            <?php while($poll = mysqli_fetch_assoc($polls_result)): ?>
                <?php
                $poll_id = $poll['id'];
                
                // Use current_status from query instead of calculating separately
                $is_ended = $poll['current_status'] === 'ended';
                $user_voted = mysqli_query($connect, "SELECT * FROM poll_votes WHERE poll_id = $poll_id AND voter_ip = '$voter_ip'");
                $has_voted = mysqli_num_rows($user_voted) > 0;
                
                // Get vote counts
                $votes_a = mysqli_fetch_assoc(mysqli_query($connect, "SELECT COUNT(*) as count FROM poll_votes WHERE poll_id = $poll_id AND voted_option = 'a'"))['count'];
                $votes_b = mysqli_fetch_assoc(mysqli_query($connect, "SELECT COUNT(*) as count FROM poll_votes WHERE poll_id = $poll_id AND voted_option = 'b'"))['count'];
                $votes_c = mysqli_fetch_assoc(mysqli_query($connect, "SELECT COUNT(*) as count FROM poll_votes WHERE poll_id = $poll_id AND voted_option = 'c'"))['count'];
                $votes_d = mysqli_fetch_assoc(mysqli_query($connect, "SELECT COUNT(*) as count FROM poll_votes WHERE poll_id = $poll_id AND voted_option = 'd'"))['count'];
                
                $total_votes = $votes_a + $votes_b + $votes_c + $votes_d;
                
                // Find winner
                $votes_array = [
                    'a' => $votes_a,
                    'b' => $votes_b,
                    'c' => $votes_c,
                    'd' => $votes_d
                ];
                $max_votes = max($votes_array);
                $winners = array_keys($votes_array, $max_votes);
                
                if($is_ended) $ended_polls_count++; else $active_polls_count++;
                ?>
                
                <div class="poll-card <?php echo $is_ended ? 'ended' : ''; ?>" id="poll-<?php echo $poll_id; ?>">
                    <div class="poll-header">
                        <div class="poll-question">
                            <?php echo htmlspecialchars($poll['question']); ?>
                            <?php if($is_ended): ?>
                                <span class="status-badge status-ended">Poll Ended</span>
                            <?php else: ?>
                                <span class="status-badge status-active">Active</span>
                            <?php endif; ?>
                        </div>
                        <div class="poll-meta">
                            <div>Ends: <?php echo date('M j, Y g:i A', strtotime($poll['ends_at'])); ?></div>
                            <div><?php echo $total_votes; ?> total votes</div>
                            <?php if($has_voted && !$is_ended): ?>
                                <div style="color: #28a745; font-weight: bold;">✓ You voted</div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <?php if($is_ended): ?>
                        <!-- Show results for ended polls -->
                        <div class="ended-message">
                            🏁 This poll has ended. Here are the final results:
                        </div>
                        <div class="poll-results">
                            <div class="results-title">Final Results</div>
                            <?php
                            $options = [
                                'a' => ['text' => $poll['option_a'], 'votes' => $votes_a],
                                'b' => ['text' => $poll['option_b'], 'votes' => $votes_b],
                                'c' => ['text' => $poll['option_c'], 'votes' => $votes_c],
                                'd' => ['text' => $poll['option_d'], 'votes' => $votes_d]
                            ];
                            
                            foreach($options as $key => $option):
                                if(!empty($option['text'])):
                                    $votes = $option['votes'];
                                    $percentage = $total_votes > 0 ? round(($votes / $total_votes) * 100, 1) : 0;
                                    $is_winner = in_array($key, $winners) && $votes > 0;
                            ?>
                                <div class="result-item">
                                    <div class="result-header">
                                        <span class="result-option">
                                            <?php echo htmlspecialchars($option['text']); ?>
                                            <?php if($is_winner): ?>
                                                <span class="winner-badge">WINNER</span>
                                            <?php endif; ?>
                                        </span>
                                        <span class="result-stats"><?php echo $votes; ?> votes (<?php echo $percentage; ?>%)</span>
                                    </div>
                                    <div class="result-bar">
                                        <div class="result-fill" style="width: <?php echo $percentage; ?>%;">
                                            <span class="result-percentage"><?php echo $percentage; ?>%</span>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; endforeach; ?>
                            
                            <?php if($total_votes == 0): ?>
                                <div style="text-align: center; color: #6c757d; font-style: italic;">
                                    No votes were cast in this poll.
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php elseif($has_voted): ?>
                        <!-- Show results after voting (active poll) -->
                        <div class="poll-results">
                            <div class="results-title">Current Results</div>
                            <?php
                            $options = [
                                'a' => ['text' => $poll['option_a'], 'votes' => $votes_a],
                                'b' => ['text' => $poll['option_b'], 'votes' => $votes_b],
                                'c' => ['text' => $poll['option_c'], 'votes' => $votes_c],
                                'd' => ['text' => $poll['option_d'], 'votes' => $votes_d]
                            ];
                            
                            foreach($options as $key => $option):
                                if(!empty($option['text'])):
                                    $votes = $option['votes'];
                                    $percentage = $total_votes > 0 ? round(($votes / $total_votes) * 100, 1) : 0;
                            ?>
                                <div class="result-item">
                                    <div class="result-header">
                                        <span class="result-option"><?php echo htmlspecialchars($option['text']); ?></span>
                                        <span class="result-stats"><?php echo $votes; ?> votes (<?php echo $percentage; ?>%)</span>
                                    </div>
                                    <div class="result-bar">
                                        <div class="result-fill" style="width: <?php echo $percentage; ?>%;">
                                            <span class="result-percentage"><?php echo $percentage; ?>%</span>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; endforeach; ?>
                        </div>
                    <?php else: ?>
                        <!-- Show voting form for active polls -->
                        <form method="POST" class="poll-options">
                            <input type="hidden" name="poll_id" value="<?php echo $poll_id; ?>">
                            
                            <div class="option-item" onclick="selectOption(this, 'a')">
                                <input type="radio" class="option-radio" name="vote_option" value="a" id="option_a_<?php echo $poll_id; ?>" required>
                                <label class="option-label" for="option_a_<?php echo $poll_id; ?>"><?php echo htmlspecialchars($poll['option_a']); ?></label>
                            </div>
                            
                            <div class="option-item" onclick="selectOption(this, 'b')">
                                <input type="radio" class="option-radio" name="vote_option" value="b" id="option_b_<?php echo $poll_id; ?>">
                                <label class="option-label" for="option_b_<?php echo $poll_id; ?>"><?php echo htmlspecialchars($poll['option_b']); ?></label>
                            </div>
                            
                            <?php if(!empty($poll['option_c'])): ?>
                            <div class="option-item" onclick="selectOption(this, 'c')">
                                <input type="radio" class="option-radio" name="vote_option" value="c" id="option_c_<?php echo $poll_id; ?>">
                                <label class="option-label" for="option_c_<?php echo $poll_id; ?>"><?php echo htmlspecialchars($poll['option_c']); ?></label>
                            </div>
                            <?php endif; ?>
                            
                            <?php if(!empty($poll['option_d'])): ?>
                            <div class="option-item" onclick="selectOption(this, 'd')">
                                <input type="radio" class="option-radio" name="vote_option" value="d" id="option_d_<?php echo $poll_id; ?>">
                                <label class="option-label" for="option_d_<?php echo $poll_id; ?>"><?php echo htmlspecialchars($poll['option_d']); ?></label>
                            </div>
                            <?php endif; ?>
                            
                            <button type="submit" name="vote_submit" class="vote-button">Submit Vote</button>
                        </form>
                    <?php endif; ?>
                </div>
            <?php endwhile; ?>
            
            <!-- Polls Summary -->
            <div style="text-align: center; color: white; margin-top: 30px;">
                <p>
                    Showing <?php echo $active_polls_count; ?> active poll<?php echo $active_polls_count != 1 ? 's' : ''; ?> 
                    and <?php echo $ended_polls_count; ?> ended poll<?php echo $ended_polls_count != 1 ? 's' : ''; ?>
                </p>
            </div>
        <?php else: ?>
            <div class="no-polls">
                <h3>No Polls Available</h3>
                <p>There are no polls at the moment. Check back later!</p>
            </div>
        <?php endif; ?>
    </div>

    <script>
        function selectOption(element, value) {
            // Remove selected class from all options
            const options = element.parentElement.querySelectorAll('.option-item');
            options.forEach(opt => opt.classList.remove('selected'));
            
            // Add selected class to clicked option
            element.classList.add('selected');
            
            // Check the radio button
            const radio = element.querySelector('input[type="radio"]');
            radio.checked = true;
        }
        
        // Auto-select option when radio is clicked
        document.querySelectorAll('.option-radio').forEach(radio => {
            radio.addEventListener('click', function(e) {
                e.stopPropagation();
                selectOption(this.parentElement, this.value);
            });
        });
    </script>
</body>
</html>