-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 11, 2025 at 03:44 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `news_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `title` longtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `image` longblob DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `description`, `image`, `created_at`) VALUES
(1, 'xvcxvcxvczxvcxv ', 'xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv ', 0x6e6577735f36393336623939663466653937312e34353936313235382e706e67, '2025-12-08 11:42:23'),
(2, 'xvcxvcxvczxvcxv ', 'xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv ', 0x6e6577735f36393336623961366563363733312e33393333343639332e706e67, '2025-12-08 11:42:30'),
(3, 'xvcxvcxvczxvcxv ', 'xvcxvcxvczxvcxvxvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv ', 0x6e6577735f36393336623961643566386636372e31373431363431322e706e67, '2025-12-08 11:42:37'),
(5, 'xvcxvcxvczxvcxv ', 'xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv xvcxvcxvczxvcxv ', 0x6e6577735f36393336623962396565383464362e37323630393237362e706e67, '2025-12-08 11:42:49'),
(8, 'A Chicken dies of heart attack due to floods caused by war', 'A Chicken dies of heart attack due to floods caused by war A Chicken dies of heart attack due to floods caused by war A Chicken dies of heart attack due to floods caused by war A Chicken dies of heart attack due to floods caused by war A Chicken dies of heart attack due to floods caused by war A Chicken dies of heart attack due to floods caused by war A Chicken dies of heart attack due to floods caused by war A Chicken dies of heart attack due to floods caused by war A Chicken dies of heart attack due to floods caused by war A Chicken dies of heart attack due to floods caused by war A Chicken dies of heart attack due to floods caused by war A Chicken dies of heart attack due to floods caused by war A Chicken dies of heart attack due to floods caused by war A Chicken dies of heart attack due to floods caused by war ', 0x6e6577735f36393361643862306532613262322e38353939313035352e6a7067, '2025-12-11 14:44:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
