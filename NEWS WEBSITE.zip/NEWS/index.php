<?php
include "admin/db.php";

// Set character encoding for database connection
mysqli_set_charset($connect, "utf8");

// Get the base directory for proper path resolution
$base_dir = __DIR__;
$uploads_dir = $base_dir . "/admin/uploads/";

// Pagination setup
$limit = 4; // 4 news per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;
$start = ($page - 1) * $limit;

// Date filter
$filter_date = isset($_GET['date']) ? mysqli_real_escape_string($connect, $_GET['date']) : '';

// Build query
$query = "SELECT * FROM news";
if($filter_date){
    $query .= " WHERE DATE(created_at) = '$filter_date'";
}
$query .= " ORDER BY created_at DESC LIMIT $start, $limit";

$result = mysqli_query($connect, $query);

// Get total rows for pagination
$count_query = "SELECT COUNT(*) as total FROM news";
if($filter_date){
    $count_query .= " WHERE DATE(created_at) = '$filter_date'";
}
$total_rows = mysqli_fetch_assoc(mysqli_query($connect, $count_query))['total'];
$total_pages = ceil($total_rows / $limit);

// Ensure page doesn't exceed total pages
if ($page > $total_pages && $total_pages > 0) {
    $page = $total_pages;
    $start = ($page - 1) * $limit;
    // Re-run query with corrected page
    $query = "SELECT * FROM news";
    if($filter_date){
        $query .= " WHERE DATE(created_at) = '$filter_date'";
    }
    $query .= " ORDER BY created_at DESC LIMIT $start, $limit";
    $result = mysqli_query($connect, $query);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Times Chronicle</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* TIMES NEWSPAPER THEME */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: Georgia, 'Times New Roman', Times, serif;
            line-height: 1.6;
            background: #f5f2eb;
            color: #222;
            padding: 20px;
            position: relative;
            min-height: 100vh;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        
        /* Times-inspired header */
        .header {
            text-align: center;
            margin-bottom: 40px;
            padding: 30px 0;
            border-bottom: 3px double #333;
            position: relative;
        }
        
        h2 {
            font-family: "Times New Roman", Times, serif;
            font-size: 3.5rem;
            font-weight: normal;
            letter-spacing: 2px;
            color: #000;
            margin-bottom: 10px;
            text-transform: uppercase;
        }
        
        .header:after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 25%;
            width: 50%;
            height: 1px;
            background: #333;
        }
        
        .subtitle {
            font-style: italic;
            color: #666;
            font-size: 1.2rem;
            margin-top: 10px;
        }
        
        /* Times-style filter */
        .filter-container {
            background: #fff;
            padding: 25px;
            margin-bottom: 40px;
            border: 1px solid #ddd;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }
        
        .filter-form {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
        }
        
        .filter-form label {
            font-weight: bold;
            color: #333;
            font-size: 1rem;
        }
        
        .filter-form input[type="date"] {
            padding: 10px 15px;
            border: 1px solid #999;
            border-radius: 0;
            font-size: 16px;
            font-family: Georgia, serif;
            background: #fff;
        }
        
        .filter-form button {
            padding: 10px 25px;
            background: #000;
            color: white;
            border: 1px solid #000;
            border-radius: 0;
            cursor: pointer;
            font-size: 16px;
            font-family: Georgia, serif;
            transition: all 0.2s;
        }
        
        .filter-form button:hover {
            background: #333;
        }
        
        .clear-filter {
            padding: 10px 25px;
            background: #fff;
            color: #000;
            text-decoration: none;
            border: 1px solid #000;
            border-radius: 0;
            font-size: 16px;
            font-family: Georgia, serif;
            transition: all 0.2s;
        }
        
        .clear-filter:hover {
            background: #f5f5f5;
        }
        
        /* News grid - Times layout */
        .news-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 30px;
            margin-bottom: 50px;
        }
        
        @media (max-width: 900px) {
            .news-grid {
                grid-template-columns: 1fr;
            }
        }
        
        /* Times-style news box */
        .news-box {
            background: #fff;
            padding: 30px;
            border: 1px solid #ddd;
            transition: all 0.3s;
            position: relative;
        }
        
        .news-box:hover {
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        }
        
        .news-box h3 {
            font-family: "Times New Roman", Times, serif;
            font-size: 1.8rem;
            line-height: 1.3;
            margin-bottom: 15px;
            color: #000;
            font-weight: bold;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
        }
        
        .image-container {
            width: 100%;
            height: 250px;
            margin-bottom: 20px;
            overflow: hidden;
        }
        
        .news-image {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.3s;
        }
        
        .news-box:hover .news-image {
            transform: scale(1.02);
        }
        
        .image-placeholder {
            width: 100%;
            height: 250px;
            background: #f9f9f9;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #999;
            font-style: italic;
            border: 1px dashed #ddd;
        }
        
        .news-date {
            color: #666;
            font-size: 0.9rem;
            margin-bottom: 15px;
            font-style: italic;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .news-description {
            color: #444;
            line-height: 1.7;
            font-size: 1.05rem;
            margin-bottom: 20px;
        }
        
        .read-more-btn {
            background: none;
            border: 1px solid #000;
            color: #000;
            padding: 8px 20px;
            font-family: Georgia, serif;
            font-size: 0.9rem;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .read-more-btn:hover {
            background: #000;
            color: #fff;
        }
        
        /* Times-style pagination */
        .pagination-container {
            margin-top: 40px;
            padding: 20px 0;
            border-top: 1px solid #ddd;
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
        }
        
        .pagination a, .pagination span {
            padding: 8px 15px;
            border: 1px solid #ddd;
            text-decoration: none;
            color: #000;
            font-family: Georgia, serif;
            transition: all 0.2s;
        }
        
        .pagination a:hover {
            background: #000;
            color: #fff;
            border-color: #000;
        }
        
        .pagination .current {
            background: #000;
            color: #fff;
            border-color: #000;
        }
        
        .pagination .disabled {
            color: #999;
            border-color: #eee;
        }
        
        /* No news message */
        .no-news {
            text-align: center;
            padding: 60px;
            background: #fff;
            border: 1px solid #ddd;
            font-style: italic;
            color: #666;
        }
        
        /* TIMES NEWSPAPER DATE/TIME DISPLAY - FIXED BOTTOM RIGHT */
        .times-clock {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: #000;
            color: #fff;
            padding: 15px 20px;
            font-family: "Times New Roman", Times, serif;
            font-size: 0.9rem;
            letter-spacing: 1px;
            z-index: 1000;
            box-shadow: 0 2px 10px rgba(0,0,0,0.3);
            min-width: 200px;
            text-align: center;
            border: 1px solid #fff;
        }
        
        .times-clock:before {
            content: '';
            position: absolute;
            top: -2px;
            left: -2px;
            right: -2px;
            bottom: -2px;
            border: 1px solid #fff;
            z-index: -1;
        }
        
        .times-clock .date {
            font-size: 1.1rem;
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        .times-clock .time {
            font-size: 1.2rem;
            font-family: 'Courier New', monospace;
            letter-spacing: 2px;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .header {
                margin-bottom: 30px;
                padding: 20px 0;
            }
            
            h2 {
                font-size: 2.5rem;
            }
            
            .filter-form {
                flex-direction: column;
                align-items: stretch;
            }
            
            .filter-form input[type="date"] {
                width: 100%;
            }
            
            .filter-form button, .clear-filter {
                width: 100%;
                text-align: center;
            }
            
            .news-grid {
                gap: 20px;
            }
            
            .news-box {
                padding: 20px;
            }
            
            .times-clock {
                bottom: 10px;
                right: 10px;
                left: 10px;
                font-size: 0.8rem;
                min-width: auto;
            }
            
            .times-clock .date {
                font-size: 1rem;
            }
            
            .times-clock .time {
                font-size: 1.1rem;
            }
        }
        
        @media (max-width: 480px) {
            h2 {
                font-size: 2rem;
            }
            
            .news-box h3 {
                font-size: 1.5rem;
            }
            
            .image-container {
                height: 200px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Times-style Header -->
        <div class="header">
            <h2>The Barandana Chronicle</h2>
            <p class="subtitle">Established 2025 • All the news that's fit to print</p>
        </div>

        <!-- Filter Section -->
        <div class="filter-container">
            <form method="GET" class="filter-form">
                <input type="hidden" name="page" value="1">
                <label for="dateFilter"><i class="fas fa-calendar"></i> Browse by Date:</label>
                <input type="date" name="date" id="dateFilter" value="<?php echo htmlspecialchars($filter_date); ?>">
                <button type="submit">
                    <i class="fas fa-search"></i> Search Archives
                </button>
                <?php if($filter_date): ?>
                    <a href="?" class="clear-filter">
                        <i class="fas fa-times"></i> Clear Search
                    </a>
                <?php endif; ?>
            </form>
        </div>

        <!-- News Grid -->
        <?php
        if(mysqli_num_rows($result) > 0){
            echo "<div class='news-grid'>";

            while($n = mysqli_fetch_assoc($result)){
                echo "<div class='news-box'>";
                echo "<h3>" . htmlspecialchars($n['title']) . "</h3>";
                
                $image_name = $n['image'];
                $image_path = "admin/uploads/" . $image_name;
                $full_image_path = $uploads_dir . $image_name;
                
                echo "<div class='image-container'>";
                if(!empty($image_name) && file_exists($full_image_path)){
                    echo "<img src='" . htmlspecialchars($image_path) . "' class='news-image' alt='" . htmlspecialchars($n['title']) . "'>";
                } else {
                    echo "<div class='image-placeholder'>";
                    echo "<i class='fas fa-image'></i>";
                    echo "<span style='margin-left: 10px;'>Image not available</span>";
                    echo "</div>";
                }
                echo "</div>";
                
                echo "<div class='news-date'>";
                echo "<i class='far fa-calendar'></i>";
                echo date('l, F j, Y', strtotime($n['created_at']));
                echo "</div>";
                
                $full_desc = nl2br(htmlspecialchars($n['description']));
                $short_desc = nl2br(htmlspecialchars(substr($n['description'], 0, 200)));
                
                if(strlen($n['description']) > 200){
                    echo "<div class='news-description'>";
                    echo "<span class='short-text'>{$short_desc}...</span>";
                    echo "<span class='full-text' style='display:none;'>{$full_desc}</span>";
                    echo "</div>";
                    
                    echo "<button class='read-more-btn'>Continue Reading <i class='fas fa-arrow-right'></i></button>";
                } else {
                    echo "<div class='news-description'>{$full_desc}</div>";
                }
                
                echo "</div>";
            }

            echo "</div>";
        } else {
            echo "<div class='no-news'>";
            echo "<h3 style='margin-bottom: 15px; color: #666;'>No Stories Found</h3>";
            echo "<p>No articles published on the selected date.</p>";
            if($filter_date) {
                echo "<p style='margin-top: 10px; font-size: 0.9rem;'>Date searched: " . htmlspecialchars($filter_date) . "</p>";
            }
            echo "</div>";
        }
        ?>

        <!-- Pagination -->
        <?php if($total_pages > 1): ?>
        <div class="pagination-container">
            <div class="pagination">
                <?php
                // Previous button
                if ($page > 1) {
                    $prev_url = "?page=" . ($page - 1);
                    if($filter_date) $prev_url .= "&date=" . urlencode($filter_date);
                    echo "<a href='$prev_url'><i class='fas fa-chevron-left'></i> Previous Page</a>";
                } else {
                    echo "<span class='disabled'><i class='fas fa-chevron-left'></i> Previous Page</span>";
                }

                // Always show first page
                if($total_pages > 1) {
                    $url = "?page=1";
                    if($filter_date) $url .= "&date=" . urlencode($filter_date);
                    $class = ($page == 1) ? 'current' : '';
                    echo "<a href='$url' class='$class'>1</a>";
                }

                // Calculate page range to show
                $start_page = max(2, $page - 2);
                $end_page = min($total_pages - 1, $page + 2);

                // Show ellipsis after first page if needed
                if ($start_page > 2) {
                    echo "<span>...</span>";
                }

                // Show page numbers
                for ($i = $start_page; $i <= $end_page; $i++) {
                    $url = "?page=$i";
                    if($filter_date) $url .= "&date=" . urlencode($filter_date);
                    $class = ($i == $page) ? 'current' : '';
                    echo "<a href='$url' class='$class'>$i</a>";
                }

                // Show ellipsis before last page if needed
                if ($end_page < $total_pages - 1) {
                    echo "<span>...</span>";
                }

                // Always show last page if there is more than one page
                if ($total_pages > 1 && $total_pages > $end_page) {
                    $url = "?page=$total_pages";
                    if($filter_date) $url .= "&date=" . urlencode($filter_date);
                    $class = ($page == $total_pages) ? 'current' : '';
                    echo "<a href='$url' class='$class'>$total_pages</a>";
                }

                // Next button
                if ($page < $total_pages) {
                    $next_url = "?page=" . ($page + 1);
                    if($filter_date) $next_url .= "&date=" . urlencode($filter_date);
                    echo "<a href='$next_url'>Next Page <i class='fas fa-chevron-right'></i></a>";
                } else {
                    echo "<span class='disabled'>Next Page <i class='fas fa-chevron-right'></i></span>";
                }
                ?>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <!-- TIMES NEWSPAPER DATE/TIME DISPLAY - FIXED BOTTOM RIGHT -->
    <div class="times-clock" id="timesClock">
        <div class="date" id="timesDate">Loading...</div>
        <div class="time" id="timesTime">00:00:00</div>
    </div>

    <script>
        // Times Newspaper Date/Time Display
        function updateTimesClock() {
            const now = new Date();
            
            // Format date in Times style
            const dateString = now.toLocaleDateString('en-US', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            });
            
            // Format time in classic style
            const timeString = now.toLocaleTimeString('en-US', {
                hour12: false,
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
            });
            
            // Update display
            document.getElementById('timesDate').textContent = dateString;
            document.getElementById('timesTime').textContent = timeString;
        }
        
        // Update immediately and every second
        updateTimesClock();
        setInterval(updateTimesClock, 1000);
        
        // Read More functionality
        document.addEventListener("DOMContentLoaded", function () {
            const buttons = document.querySelectorAll(".read-more-btn");
            
            buttons.forEach(btn => {
                btn.addEventListener("click", function () {
                    const box = this.parentElement;
                    const shortText = box.querySelector(".short-text");
                    const fullText = box.querySelector(".full-text");
                    
                    if (fullText.style.display === "none") {
                        fullText.style.display = "block";
                        shortText.style.display = "none";
                        this.innerHTML = "Show Less <i class='fas fa-arrow-up'></i>";
                    } else {
                        fullText.style.display = "none";
                        shortText.style.display = "block";
                        this.innerHTML = "Continue Reading <i class='fas fa-arrow-right'></i>";
                    }
                });
            });
            
            // Add newspaper vibe - subtle animation to clock
            const timesClock = document.getElementById('timesClock');
            let pulse = false;
            setInterval(() => {
                pulse = !pulse;
                timesClock.style.borderColor = pulse ? '#ccc' : '#fff';
            }, 1000);
            
            // Today button for date filter
            const dateFilter = document.getElementById('dateFilter');
            if(dateFilter) {
                const today = new Date().toISOString().split('T')[0];
                dateFilter.max = today;
            }
        });
    </script>
</body>
</html>