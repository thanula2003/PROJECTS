<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>

    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f4f4f4;
        }

        .header {
            background: #2d89ef;
            color: white;
            padding: 20px;
            text-align: center;
            font-size: 28px;
            font-weight: bold;
        }

        .container {
            width: 90%;
            max-width: 900px;
            margin: 30px auto;
        }

        .section-title {
            font-size: 22px;
            margin: 20px 0 10px;
            color: #333;
            font-weight: bold;
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
        }

        .card {
            background: white;
            padding: 25px;
            border-radius: 8px;
            border: 1px solid #ddd;
            text-align: center;
        }

        .btn {
            display: inline-block;
            background: #2d89ef;
            padding: 10px 18px;
            border-radius: 6px;
            text-decoration: none;
            color: white;
            font-size: 16px;
            font-weight: bold;
        }

        .btn:hover {
            background: #1f63b7;
        }
    </style>
</head>
<body>

    <div class="header">XYZ NEWS Admin Panel</div>

    <div class="container">

        <h3 class="section-title">Add New Content</h3>
        <div class="grid">
            <div class="card">
                <a href="add.php" class="btn">Add News</a>
            </div>
        </div>

        <h3 class="section-title">Manage Existing Content</h3>
        <div class="grid">
            <div class="card">
                <a href="delete.php" class="btn">Manage News</a>
            </div>
        </div>

    </div>

</body>
</html>
