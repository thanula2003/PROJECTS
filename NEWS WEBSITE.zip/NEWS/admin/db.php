<?php
$connect = mysqli_connect(
    hostname: "localhost",
    username:"root",
    password: "",
    database: "news_db");
mysqli_set_charset($connect, "utf8mb4");
if(!$connect){
    die("DB Connection Failed");
}
?>
