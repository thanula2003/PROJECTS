<?php
include "db.php";

// Set proper character encoding
header('Content-Type: text/html; charset=utf-8');

// Delete action
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];

    // First get image name to delete file from folder
    $stmt = mysqli_prepare($connect, "SELECT image FROM news WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $imgRow = mysqli_fetch_assoc($result);
    mysqli_stmt_close($stmt);

    if ($imgRow && !empty($imgRow['image'])) {
        $imgPath = "uploads/" . $imgRow['image'];
        // Delete image file
        if (file_exists($imgPath)) {
            unlink($imgPath);
        }
    }

    // Delete DB record
    $stmt = mysqli_prepare($connect, "DELETE FROM news WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header("Location: delete.php?success=1");
    exit;
}

// Fetch all news
$news = mysqli_query($connect, "SELECT * FROM news ORDER BY id DESC");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>News Management - Delete Articles</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background-color: #f8f9fa;
            padding: 20px;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.05);
            overflow: hidden;
        }
        
        header {
            background: #fff;
            padding: 25px 30px;
            border-bottom: 1px solid #eaeaea;
        }
        
        h1 {
            font-size: 24px;
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 5px;
        }
        
        .subtitle {
            color: #7f8c8d;
            font-size: 14px;
        }
        
        .alert {
            padding: 12px 20px;
            margin: 20px 30px 0;
            border-radius: 6px;
            font-size: 14px;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .table-container {
            padding: 30px;
            overflow-x: auto;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            font-size: 14px;
        }
        
        thead {
            background-color: #f8f9fa;
        }
        
        th {
            text-align: left;
            padding: 16px 12px;
            font-weight: 600;
            color: #2c3e50;
            border-bottom: 2px solid #eaeaea;
            white-space: nowrap;
        }
        
        td {
            padding: 16px 12px;
            border-bottom: 1px solid #eaeaea;
            vertical-align: top;
        }
        
        tr:hover {
            background-color: #f8f9fa;
        }
        
        .news-image {
            width: 80px;
            height: 60px;
            object-fit: cover;
            border-radius: 4px;
            border: 1px solid #eaeaea;
        }
        
        .news-title {
            font-weight: 500;
            color: #2c3e50;
            margin-bottom: 5px;
            line-height: 1.4;
        }
        
        .news-description {
            color: #7f8c8d;
            font-size: 13px;
            line-height: 1.5;
        }
        
        .action-cell {
            white-space: nowrap;
        }
        
        .btn-delete {
            display: inline-block;
            background: #e74c3c;
            color: white;
            padding: 8px 16px;
            text-decoration: none;
            border-radius: 4px;
            font-size: 13px;
            font-weight: 500;
            border: none;
            cursor: pointer;
            transition: background-color 0.2s;
        }
        
        .btn-delete:hover {
            background: #c0392b;
        }
        
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: #7f8c8d;
        }
        
        .empty-state p {
            margin-bottom: 15px;
        }
        
        @media (max-width: 768px) {
            .container {
                border-radius: 0;
            }
            
            header, .table-container {
                padding: 20px 15px;
            }
            
            th, td {
                padding: 12px 8px;
            }
            
            .news-title {
                font-size: 14px;
            }
            
            .news-description {
                font-size: 12px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>News Management</h1>
            <p class="subtitle">Delete news articles from the system</p>
            <a href="home.php" class="back-button">← Back to Dashboard</a>
        </header>

        <?php if (isset($_GET['success'])): ?>
            <div class="alert alert-success">
                News article deleted successfully.
            </div>
        <?php endif; ?>

        <div class="table-container">
            <?php if (mysqli_num_rows($news) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Image</th>
                            <th>Title</th>
                            <th>Description</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($news)): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['id']) ?></td>
                            <td>
                                <?php if (!empty($row['image'])): ?>
                                    <img src="uploads/<?= htmlspecialchars($row['image']) ?>" alt="News image" class="news-image">
                                <?php else: ?>
                                    <div style="width:80px; height:60px; background:#f8f9fa; border-radius:4px; display:flex; align-items:center; justify-content:center; color:#7f8c8d; font-size:12px;">
                                        No Image
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="news-title"><?= htmlspecialchars($row['title']) ?></div>
                            </td>
                            <td>
                                <div class="news-description">
                                    <?= 
                                        strlen($row['description']) > 120 
                                        ? htmlspecialchars(substr($row['description'], 0, 120)) . '...' 
                                        : htmlspecialchars($row['description']) 
                                    ?>
                                </div>
                            </td>
                            <td class="action-cell">
                                <a class="btn-delete" 
                                   href="delete.php?delete=<?= $row['id'] ?>"
                                   onclick="return confirm('Are you sure you want to delete this news article? This action cannot be undone.');">
                                   Delete
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="empty-state">
                    <p>No news articles found.</p>
                    <p>Add some news articles to see them listed here.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
